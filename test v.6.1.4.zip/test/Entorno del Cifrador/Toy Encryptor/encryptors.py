'''Módulo encriptador del dispositivo'''
import sys
import random

from chepy import Chepy

class Encryptor():

    '''Clase para los objetos que ayudan al cifrado'''

    def __init__(self, alg, enck):
        '''Constructor de la clase'''
        self.alg = alg
        self.enck = enck

    def random_war_phrase(self):

        '''Método que devuelve una frase aleatoria para simular las comms'''

        phrases = [
            "¡Menos mal que has escrito!, nos ganan en número. Necesitamos refuerzos.",
            "¡Estás bien! Te dábamos por muerto.",
            "Estamos heridos, al borde de la muerte",
            "Herida de bala... me queda poco tiempo... Ayuda...",
            "¡De camino!",
            "¡Sin munición!",
            "No puedo escribir ahora, la guerra está que arde.",
            "Aquí el escuadrón salchicha, ¿nos recibes?"
        ]
        return random.choice(phrases)

    def encr_select(self, inpt):

        '''Método para elegir la encriptación'''

        try:
            msg = inpt

            if self.alg.upper() == "XOR":
                msg = Chepy(inpt).xor(self.enck, enck_type="utf-8").to_hex()
            elif self.alg.upper() == "VIGENERE":
                msg = Chepy(inpt).vigenere_encode(self.enck).o
            elif self.alg.upper() == "3DES":
                msg = Chepy(inpt).triple_des_encrypt(self.enck, mode="ECB").o
            elif self.alg.upper() == "ROT13":
                msg = Chepy(inpt).rot_13()
            elif self.alg.upper() == "ROT47":
                msg = Chepy(inpt).rot_47().out
            elif self.alg.upper() == "RC4":
                msg = Chepy(inpt).rc4_encrypt(self.enck).o
            elif self.alg.upper() == "AES-ECB":
                msg = Chepy(inpt).aes_encrypt(self.enck, mode="ECB").o

            return msg
        except ValueError:
            print(
                "\n\033[91mLOADED FORBIDDEN KEY. "+
                "STOPPING COMMS. LOAD VALID KEY.\033[0m"
            )
            sys.exit()

    def decr_select(self, inpt):

        '''Método para la seleccionar la desencriptación'''

        try:
            msg = inpt

            if self.alg.upper() == "XOR":
                msg = Chepy(inpt).xor(self.enck, enck_type="utf-8").to_hex()
            elif self.alg.upper() == "VINGERE":
                msg = Chepy(inpt).vigenere_decode(self.enck).o
            elif self.alg.upper() == "3DES":
                msg = Chepy(inpt).triple_des_decrypt(self.enck, mode="ECB").o
            elif self.alg.upper() == "ROT13":
                msg = Chepy(inpt).rot_13()
            elif self.alg.upper() == "ROT47":
                msg = Chepy(inpt).rot_47().out
            elif self.alg.upper() == "RC4":
                msg = Chepy(inpt).rc4_decrypt(self.enck).o
            elif self.alg.upper() == "AES-ECB":
                msg = Chepy(inpt).aes_decrypt(self.enck, mode="ECB").o

            return msg
        except ValueError:
            print(
                "\n\033[91mLOADED FORBIDDEN KEY. "
                +"STOPPING COMMS. LOAD VALID KEY.\033[0m"
            )
            sys.exit()
