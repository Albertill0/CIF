'''Módulo para el SGBD que trabaja con la clase usuario'''
import json
import random
import string
import os
import sys
import getpass

# pylint: disable=C2801
# pylint: disable=W1514
# pylint: disable=C0301

class User():

    '''Clase para instanciar usuarios en el SGBD'''

    def __init__(self, username, password, role, active_profile, attempts):
        '''Constructor'''
        self.username = username
        self.password = password
        self.role = role
        self.active_profile = active_profile
        self.attempts = attempts

    def to_string(self):
        '''Método toString de la clase'''
        return f"Username: {self.username}, Password: {self.password}, Role: {self.role}, Active Profile: {self.active_profile}, Attempts: {self.attempts}"

class Sgbd():

    '''Clase para implementar el SGBD'''

    def __init__(self,nombre,target):
        '''Constructor'''
        self.nombre = nombre
        self.target = target

    def to_string(self):
        '''Método toString de la clase'''
        return "Name: " + self.nombre + ", Target: " + self.target

    def write_random_examples(self):
        '''Método que construye ejemplos random a base de submétodos auxiliares. GITHUB COPILOT'''

        def random_string():
            '''Método que genera un string random'''
            with open(f"dics/{random.choice(string.ascii_lowercase)}.txt") as file:
                return random.choice(
                    [
                        line.strip()
                        for line in file.readlines()
                        if not line.strip().startswith(("#", ",", " "))
                    ]
                )

        def random_bool():
            '''Método que genera un booleano random'''
            return random.choice([True, False])

        def random_role():
            '''Método que genera un rol aleatorio'''
            return random.choice(
                ["Management"] + [f"Squad-{random.randint(1, 10)}" for i in range(10)]
            )

        def random_user():
            '''Método que genera un usuario aleatorio'''
            return User(random_string(), random_string(), random_role(), random_bool(), 3)

        with open("users.json", "w") as file:
            json.dump([random_user().__dict__ for i in range(10)], file)

    def read_users(self):
        '''Método que lee usuarios'''
        with open("users.json") as file:
            users = json.load(file)
            for user in users:
                hidden_input = "*" * len(user["password"])
                print(
                    User(
                        user["username"],
                        hidden_input,
                        user["role"],
                        user["active_profile"],
                        user["attempts"],
                    ).to_string()
                )
            print("                                                      ")
            print("                                                      ")
            print("                                                      ")


    def add_user(self):
        '''Método que añade un usuario a la BD por entrada del usuario'''

        try:
            with open("users.json") as file:
                users = json.load(file)
                username = input("Username: ")
                password = getpass.getpass(prompt="Password: ", stream=None)
                hidden_input = "*" * len(password)
                print(hidden_input)
                while True:
                    print("Select role: Management or Squad")
                    role = input("Role: ")
                    if role.lower().__contains__("management") or role.lower().__contains__(
                        "squad"
                    ):
                        # If role is squad, then it must be followed by a random number between 1 and 10
                        if role.lower().__contains__("squad"):
                            role = f"{role}-{random.randint(1, 10)}"
                        break
                    print("Please, select one role from those said")

                while True:
                    print("Select Activate user or not: true or false")
                    active_profile = input("Active Profile: ")
                    if active_profile.lower().__contains__(
                        "true"
                    ) or active_profile.lower().__contains__("false"):
                        break
                    print("Please, select one either true or false")
                users.append(User(username, password, role, active_profile, 3).__dict__)
            with open("users.json", "w") as file:
                json.dump(users, file)
        except FileNotFoundError:
            print("File not found, create file first...")

    def delete_file(self):
        '''Método para borrar el fichero de BD json'''
        os.system("rm users.json")

    def exit_program(self):
        '''Método para salir del SGBD'''
        sys.exit()

    def menu(self):
        '''Método de menú principal'''

        print(" ************** WELCOME TO DATABASE MANAGER **********")
        print("                                                      ")
        while True:
            print("1. Delete all users")
            print("2. Create database")
            print("3. Show all users")
            print("4. Add an user")
            print("5. Exit the program")
            print("                                                      ")
            print("                                                      ")
            print("                                                      ")
            option = input("Choose an option: ")
            if option == "1":
                self.delete_file()
            elif option == "2":
                self.write_random_examples()
            elif option == "3":
                try:
                    self.read_users()
                except EOFError:
                    print("No users in database. Try to create")
                    self.menu()
            elif option == "4":
                self.add_user()
            elif option == "5":
                self.exit_program()
            else:
                print("Invalid option")


sistema_gestor = Sgbd("Sistema gestor de BBDD", "Management Centre")
try:
    sistema_gestor.menu()
except BaseException:
    print("\033[91mCorrupt Database File. Could not read")
