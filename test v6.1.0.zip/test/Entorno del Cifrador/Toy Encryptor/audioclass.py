'''Módulo para generar el walkieTalkie de comms por voz'''
import sounddevice as sd

class WalkieTalkie():

    '''Clase para crear instancias de walkie'''

    def __init__(self, tipo, band, channel, frequency):
        '''Constructor de la clase'''
        self.tipo = tipo
        self.band = band
        self.channel = channel
        self.frequency = frequency

    def to_string(self):

        '''Método toString de la clase'''

        return (
            "Type: "
            + self.tipo
            + "\nBand: "
            + self.band
            + "\nChannel: "
            + self.channel
            + "\nFrequency: "
            + self.frequency
        )

    def record(self, inp):

        '''Método para grabar'''

        sample_rate = 44100
        device_index = inp

        audio = sd.InputStream(
            samplerate=sample_rate, device=device_index, channels=2, dtype="int16"
        )

        audio.start()
        print("Recording...")
        print("Recording done!")
        audio.stop()
        audio_data = audio.read(audio)

        return audio_data
