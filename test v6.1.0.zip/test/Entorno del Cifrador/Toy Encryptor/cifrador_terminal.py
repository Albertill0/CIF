'''Módulo para la implementación del encriptador para el problema'''
import json
import os
import shlex
import sys
import pulsectl
import speech_recognition as sr

from gtts import gTTS
from audioclass import WalkieTalkie
from auditor import Auditor
from micro_sd import SdCard
from encryptors import Encryptor

# pylint: disable=W0601
# pylint: disable=C0301
# pylint: disable=R1710
# pylint: disable=C2801
# pylint: disable=R0903
# pylint: disable=W1514
# pylint: disable=R1702
# pylint: disable=W0311

class Toyencryptor():

    '''Clase del encriptador de juguete'''
    TRIESCOUNTER = 3
    ALGORITHM = ""
    RUTASD = "/mnt"
    ROUTEUPDATES = RUTASD + "/Updates"
    ROUTEKEYLOADING = RUTASD + "/Missions"
    DATABASE = RUTASD + "/Database"
    ENCRYPTIONKEY = ""
    SD = "NOinsert"
    LIGHT = True
    COMMWRITE = False
    COMMSPEAK = False
    NONCONCURRENTCOMS = False
    COMBATIENT = ""
    VIGILANTE = Auditor("Luis Enrique, el auditor", "Toy Encryptor")

    def __switch_toy(self):

        '''Método de cambios de estado encendido/apagado'''

        if Toyencryptor.LIGHT is True:
            return "\033[91m"+""

        return "\033[30m"+""


    def __toy(self):

        '''Método para dibujar el ASCII del encriptador de juguete en consola'''

        print("\n\n\033[38;2;0;0;1m                           ##")
        print("                           ||")
        print("\t   " + self.__switch_toy() + "0\033[38;2;0;0;1m               ||")
        print("################################")
        print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
        print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
        print("#@@\033[92m1.*Insert the Micro-SD*\033[38;2;0;0;1m@@@@@#")
        print("#@@\033[92m2.*Press 'Zeroize' Button*\033[38;2;0;0;1m@@#")
        print("#@@\033[92m3.*Unmount SD & Switch OFF*\033[38;2;0;0;1m@#")
        print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
        print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
        print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
        print("#@@@@@@@@@@@\033[0m" + self.__switch_microsd(Toyencryptor.SD) + "\033[38;2;0;0;1m@@@@@@@@@@@#")
        print("################################\033[38;2;0;0;1m")
        print("        " + self.__comm_lights() + "               " + self.__comm_lights() + " \n\n")


    def __switch_microsd(self,action):

        '''Método para cambiar el estado de la micro-sd de cara al ASCII'''

        if action == "NOinsert":
            return "\033[0m[======]\033[30m"+""
        if action == "insert":
            return "\033[0m[\033[40m      \033[m]\033[30m"+""


    def __first_menu(self):

        '''Método para el primer menú de opciones del encriptador'''

        self.__toy()
        tarjeta = SdCard("Micro-SD", "8GB", "FAT32")

        while True:
            userchoice = input("\nPlease, enter a number: ")
            if userchoice in ("1","2","3"):
                break
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Error.Invalid option", "first_menu => FAIL, with menu_option selected="+userchoice)
            print("\n\033[91m (Audited) Error.Invalid option \033[0m\n")

        if userchoice == "1":
            print("\n\033[93m  * You inserted the Micro-SD... *\033[0m\n")
            Toyencryptor.SD = "insert"
            readable_card = tarjeta.sd_mount(Toyencryptor.RUTASD)
            if not readable_card:
                Toyencryptor.SD = "NOinsert"
                self.__first_menu()
                return False
            self.__toy()
            self.__read_fu()
            tarjeta.sd_umount(Toyencryptor.RUTASD)

        elif userchoice == "2":
            print("\033[93m \n* You zeroized the Toy Encryptor... *\033[0m\n")
            Toyencryptor.LIGHT = False
            readable_card = tarjeta.sd_mount(Toyencryptor.RUTASD)
            if not readable_card:
                Toyencryptor.SD = "NOinsert"
                self.__toy()
                return False
            Toyencryptor.SD = "insert"
            self.__zerioze()
            tarjeta.sd_mount(Toyencryptor.RUTASD)
        else:
            self.__turn_off(tarjeta)
            sys.exit()

    def __turn_off(self,tarjeta):

        '''Método de apagado'''

        print("\n\033[93m* Switched OFF... No more BIP BIP BOOP *\n")
        Toyencryptor.LIGHT = False
        readable = tarjeta.sd_mount(Toyencryptor.RUTASD)

        if not readable:
            print(
                "\n\033[93m*No Micro-SD card pending to retire after switching off...*\n\033[0m"
            )
            Toyencryptor.SD = "NOinsert"
        else:
            print(
                "\n\033[93m*Micro-SD Card pending to retire... Retire it from device*\n\033[0m"
            )
            Toyencryptor.SD = "insert"

        self.__toy()

    def __delete_db(self):

        '''Método de borrado de la BBDD'''

        try:
            retdir = os.getcwd()

            if os.getcwd() != Toyencryptor.DATABASE:
                os.chdir(Toyencryptor.DATABASE)
            code = os.system("sudo rm " + shlex.quote("users.json") + " > /dev/null 2>&1")

            if code != 0:
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Database was mainly cleansed", "delete_db => SUCCESS")
                print("\033[91m (Audited)\033[0m\n")
            os.chdir(retdir)
        except FileNotFoundError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "No database to delete", "delete_db => FAIL")
            print("\033[91m (Audited)\033[0m\n")


    def init(self):

        '''Llamada de encendido al Toy encryptor'''

        print("\n\033[93m Toy Encryptor turned ON...\n "
              + "* Device sounds... BIP BIP BOOP *\n")
        print(
            " * LED Light turned on... Device ready to use... * \n "
            + "* There's not Micro-SD inserted to read yet... *"
        )
        print("\nNow device is ready for user manipulation..."
              + " What would you do? \n\033[0m")

        self.__first_menu()

    def __read_fu(self):

        '''Método de lectura de actualizaciones firmware'''

        print("\n\033[93m *Reading for updates...*\n")
        check_for_updates = True

        try:
            route_updates_list = os.listdir(Toyencryptor.ROUTEUPDATES)

            if len(route_updates_list) <= 0:
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "No firmware updates", "read_fu => FAIL (CONTINUE)")
                print("\033[91m (Audited)\033[0m\n")
                check_for_updates = False

            if check_for_updates:
                update_index = 0

                for file in route_updates_list:
                    if file.lower().__contains__(".sh"):
                        print(
                            "\n\033[94m ***---- PREPARING UPTADE " + str(update_index) + "----***\n"
                        )
                        self.__updates_exec(Toyencryptor.ROUTEUPDATES, file)
                        update_index += 1

                print("\n\033[32mEnd of updates \033[0m\n")

            self.__read_mi()
        except FileNotFoundError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, " No file at reading updates" , "read_fu => FAIL")
            print("\033[91m (Audited)\033[0m\n")
        except NotADirectoryError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "No directory at reading updates ", "read_fu => FAIL")
            print("\033[91m (Audited)\033[0m\n")

    def __updates_exec(self,path, file):

        '''Método de ejecución de actualizaciones firmware'''

        ret_route = os.getcwd()

        if os.getcwd() != path:
            os.chdir(path)

        os.system("ls")
        os.system("sudo chmod +x " + shlex.quote(file))
        os.system("/bin/bash " + file)
        os.system("sudo rm " + file + " > /dev/null 2>&1")
        os.chdir(ret_route)

    def __read_mi(self):

        '''Método de lectura de misiones del encriptador'''

        print("\n\033[93m Reading for Missions...\n\033[91m")

        try:
            key_loading_list = os.listdir(Toyencryptor.ROUTEKEYLOADING)
            nfiles = len(key_loading_list)

            if nfiles <= 0:
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "There are no keys to read. Unable to use device.", "read_mi => FAIL (CONTINUE)")
                print("\033[91m (Audited)\033[0m\n")
                self.__first_menu()
                return False

            for file in key_loading_list:
                nfiles -= 1
                verify_login = False
                if file.lower().__contains__(".json"):
                    auxiliar_path = Toyencryptor.ROUTEKEYLOADING + "/" + file
                    verify_login = self.__log_in(auxiliar_path)

                    if verify_login is True:
                        Toyencryptor.TRIESCOUNTER = 3
                        break

                    if Toyencryptor.TRIESCOUNTER <= 0:
                        Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "ERROR! ERROR! DETECTED INTRUDER."
                        + "STARTING SECURITY PROCEDURE", "read_mi => FAIL (PROBLEM EXPLOIT)")
                        print("\033[91m (Audited)\033[0m\n")
                        erase = os.listdir(Toyencryptor.ROUTEKEYLOADING)
                        if len(erase) > 0:
                            for auxiliar_path in erase:
                                erase_keys = Toyencryptor.ROUTEKEYLOADING + "/" + auxiliar_path
                                self.toast(erase_keys)
                            break  # Intentional jump here
                        # Exploit : Never Ends execution afer toasting,
                        # access to comms without key. Just stops reading credentials after having deleted (BAD CODE).
                        # Now Key is none, comms are wit1hout encrypting

                    if nfiles == 0 and Toyencryptor.TRIESCOUNTER > 0:
                        Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Could not verify credentials credentials for Encryptor Usage", "read_mi => FAIL")
                        print("\033[91m (Audited)\033[0m\n")
                        Toyencryptor.LIGHT = False
                        self.__toy()
                        return False

            self.__comms_menu()
        except FileNotFoundError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Unexpected error reading keys or database", "read_mi => FAIL")
            print("\033[91m (Audited)\033[0m\n")

    def __comms_menu(self):

        '''Método para el menú de comunicaciones'''

        print("\n\033[38;5;129m Algorithm: -> " + Toyencryptor.ALGORITHM + " <-\033[0m")
        print("\033[38;5;129m With Key: -> " + Toyencryptor.ENCRYPTIONKEY + " <-\033[0m\n")
        print(
            "\n\033[93m* Communications are ready."
            + "Device waiting for user action... \033[0m*\n"
        )

        while True:
            userinput = input(
                "\033[92m\n1. * Turn on and attach the computer to write"
                + "a message for the squad \n(Lights YELLOW left LED)*\n\n2. "
                + "* Turn on and attach the walkie-talkie to send voice message"
                + "to the squad \n(Lights BLUE Right LED) "
                + "*\n\n3. * Leave communications * \n"
            )

            if userinput in ("1", "2", "3"):
                break
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Invalid action for comms system", "comms_menu => FAIL")
            print("\033[91m \nInvalid action for comms system\033[0m\n")

        if userinput == "1":
            print(
                "\n\033[93m * Click! - Attached computer"
                + "to encryptor. \nTurned on... * \n"
            )
            Toyencryptor.COMMWRITE = True
            self.__toy()
            self.__comms_write()
        elif userinput == "2":
            print(
                "\n\033[93m * Click! - Attached walkie-talkie to encryptor. \nTurned on... * \n"
            )
            Toyencryptor.NONCONCURRENTCOMS = True
            Toyencryptor.COMMSPEAK = True
            self.__toy()
            self.__comms_voice()
        else:
            self.__first_menu()

    def __comm_lights(self):

        '''Método de switching de leds de comunicación'''

        if Toyencryptor.NONCONCURRENTCOMS is True:
            Toyencryptor.NONCONCURRENTCOMS = False
            return "\033[30m0"

        if Toyencryptor.COMMSPEAK is True and Toyencryptor.COMMWRITE is False:
            Toyencryptor.COMMWRITE = False
            Toyencryptor.COMMWRITE = False
            return "\033[38;2;0;128;255m0\033[m"

        if Toyencryptor.COMMWRITE is True and Toyencryptor.COMMSPEAK is False:
            Toyencryptor.COMMWRITE = False
            Toyencryptor.COMMSPEAK = False
            return "\033[38;2;255;255;0m0\033[m"

        return "\033[38;2;0;0;1m0"

    def __communicate(self,inpt, mode):

        '''Método de comunicación'''

        try:
            encriptador = Encryptor(Toyencryptor.ALGORITHM, Toyencryptor.ENCRYPTIONKEY)
            msg_sent = str(encriptador.encr_select(inpt))
            respuesta = str(encriptador.encr_select(encriptador.random_war_phrase()))

            if mode.upper() == "CHAT":
                if len(inpt) > 0:
                    print(
                        "\n\033[38;5;129mSquad Member - "
                        + Toyencryptor.COMBATIENT
                        + " >>> \033[38;5;208mS"
                        + msg_sent
                        + "\033[0m\n"
                    )
                    print(
                        "\033[38;5;129mSquad Member(s) >>>\033[38;5;208m "
                        + respuesta
                        + "\033[38;5;129m\n"
                    )
            elif mode.upper() == "VOICE":
                # decode missing
                msg = encriptador.decr_select(respuesta)
                return msg
            else:
                raise IOError()
        except IOError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Error in comms mode", "communicate => FAIL")
            print("\033[91m (Audited)\033[0m\n")
            return False

    def __comms_write(self):

        '''Método de escritura cifrada para la comunicación del encriptador'''

        while True:
            inpt = input(
                "\n\033[32mComputer ready. Write down your message, "
                + "other encryptors belonging to the same squad will"+
                "receive your message\033[0m\n\n"
            )
            self.__communicate(inpt, "CHAT")
            while True:
                respuesta = input("Do you want to send other written message? (y/n): ")
                if respuesta.lower() == "n":
                    Toyencryptor.COMMWRITE = False
                    self.__comms_menu()
                elif respuesta.lower() == "y":
                    break
                else:
                    Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Invalid option", "comms_write => FAIL")
                    print("\033[91m (Audited)\033[0m\n")

    def __read_audio(self):

        '''Método de lectura de audio que transcribe a texto y cifra. No funciona por ahora'''

        sample_rate = 0
        channel = 0
        walkie = WalkieTalkie("Walkie-Talkie", "2.4GHz", "16", "44100Hz")

        try:
            with pulsectl.Pulse("") as pulse:
                for source in pulse.source_list():
                    if source.description.startswith("Monitor of USB"):
                        channel = int(source.channel_count)
                        sample_rate = source.configured_latency
                        break

            print(
                "\n\033[93m* Walkie-Talkie Info: \n"
                + walkie.to_string()
                + "\nReady for usage... Recording...\033[0m\n"
            )

            audio = walkie.record(channel)
            audio_data = sr.AudioData(audio, sample_rate, 2)
            lector_audio = sr.Recognizer()
            texto = lector_audio.recognize_google(audio_data, language="es-ES")
            respuesta = self.__communicate(texto, "VOICE")
            tts = gTTS(respuesta, lang="es")
            tts.save("respuesta.mp3")
            os.system(f"mpg321 respuesta.mp3")
        except IOError as io_error:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Could not read audio INPUT. "+
            "Try again connections to plug-in the walkie."
            + "Additional info in : "
            + str(io_error), "read_audio => FAIL")
            print("\033[91m (Audited)\033[0m\n")
            return False

    def __comms_voice(self):

        '''Método de llamada a la comunicación por audio'''

        while True:
            can_send_audio = self.__read_audio()

            while True:

                if can_send_audio is False:
                    Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Exists a problem with the voice mode. "
                    + "Better not use this mode at the moment", "comms_voice => FAIL (CONTINUE)")
                    print("\033[91m (Audited)\033[0m\n")
                    Toyencryptor.COMMSPEAK = False
                    self.__comms_menu()

                respuesta = input("Do you want to send other voice message? (y/n): ")

                if respuesta.lower() == "n":
                    Toyencryptor.COMMSPEAK = False
                    self.__comms_menu()
                elif respuesta.lower() == "y":
                    break
                else:
                    Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Invalid option", "comms_voice => FAIL")
                    print("\033[91m (Audited)\033[0m\n")

    def __del_audits(self):

        '''Método para borrar las auditorías'''
        try:
            auditing = "archivo_auditoria.txt"
            os.remove(auditing)
        except FileNotFoundError:
            return False

    def __zerioze(self):

        '''Método para zeroizar el cifrador'''

        try:
            key_loading_list = os.listdir(Toyencryptor.ROUTEKEYLOADING)

            if len(key_loading_list) > 0:
                for file in key_loading_list:
                    if file.lower().__contains__(".json"):
                        auxiliar_path = Toyencryptor.ROUTEKEYLOADING + "/" + file
                        self.__toast(auxiliar_path)
                self.__toy()
                self.__delete_db()
                self.__del_audits()
                print("\n\033[93m Zeroized device... Useless Toy Now.. Switching OFF!\n")
                print("\n* STOPPED BIP BIP BOOP . Retire Micro-SD* \033[0m\n")
                sys.exit()
            else:
                self.__toy()
                self.__delete_db()
                self.__del_audits()
                print("\n\033[93m * Nothing supposed to happen *\033[0m\n")
        except FileNotFoundError:
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Unexpected error zeroizing!!!", "zeroize => FAIL")
                print("\033[91m (Audited)\033[0m\n")

    def __toast(self,path):

        '''Método para borrar archivos en el zeroizado'''

        Toyencryptor.ALGORITHM = ""

        os.remove(path)

        to_clear = os.listdir(Toyencryptor.ROUTEUPDATES)
        if len(to_clear) > 0:
            for file in to_clear:
                auxiliar_path = Toyencryptor.ROUTEUPDATES + "/" + file
                os.remove(auxiliar_path)

    def __verify_squad(self,squad):

        '''Método de verificación del número de squad del combatiente'''

        number = squad.split("-")[1]

        if int(number) in range(11):
            return True

        return False

    def __read_db(self):

        '''Método de lectura de la BBDD'''

        try:
            names = []
            retdir = os.getcwd()

            if os.getcwd() != Toyencryptor.DATABASE:
                os.chdir(Toyencryptor.DATABASE)
            os.system("sudo chmod +r " + shlex.quote("users.json") + " > /dev/null 2>&1")

            with open("users.json", "r") as file:
                users_database = json.load(file)
                file.close()
                for auxuser in users_database:
                    names.append(auxuser["username"])
            os.chdir(retdir)
            return names
        except FileNotFoundError:
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Could not read database. "
                                  + "Remove SD and load database again", "read_db => FAIL")
            print("\033[91m (Audited)\033[0m\n")
            Toyencryptor.LIGHT = False
            self.__toy()
            sys.exit()

    def __log_in(self,auxiliar_path):

        '''Método de inicio de sesión en el dispositivo'''

        attempts = 0

        try:
            names = self.__read_db()

            with open(auxiliar_path, "r") as file:
                user = json.load(file)
                file.close()

                if (
                    len(user["username"]) <= 0
                    or len(user["role"]) <= 0
                    or len(user["algorithm"]) <= 0
                ):
                    raise ValueError()

            if not user["username"] in names:
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Unexistent user the one loaded at SD", "log_in => FAIL")
                print("\033[91m (Audited)\033[0m\n")
                raise ValueError()

            if not user["role"].lower().__contains__("squad"):
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "User not part of the mission's squad", "log_in => FAIL")
                print("\033[91m (Audited)\033[0m\n")
                raise ValueError()

            if not self.__verify_squad(user["role"]):
                Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Unexistent squad entered", "log_in => FAIL")
                print("\033[91m (Audited)\033[0m\n")
                raise ValueError()

            return self.__set_encryptor_key(user["algorithm"], user["key"], user["username"])
        except ValueError:
            attempts += 1
            Toyencryptor.TRIESCOUNTER -= 1
            Toyencryptor.VIGILANTE.start_audit(Toyencryptor.COMBATIENT, "Error reading credentials. "
            + "Attempt -> "+ str(attempts), "log_in => FAIL")
            print("\033[91m (Audited)\033[0m\n")

    def __set_encryptor_key(self,algorithm, key, combatient):

        '''Método de establecimiento de claves en el dispositivo'''

        if len(algorithm) > 0 and len(combatient):
            Toyencryptor.COMBATIENT = combatient
            Toyencryptor.ALGORITHM = algorithm
            Toyencryptor.ENCRYPTIONKEY = key
            return True

        return False

toy = Toyencryptor()
toy.init()
