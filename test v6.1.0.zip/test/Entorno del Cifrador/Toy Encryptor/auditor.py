'''Módulo observador que actua de auditor'''
from datetime import datetime

class Auditor():

    '''Clase para crear instancias de auditor que apunten'''

    def __init__(self, nombre, target):
        '''Constructor de la clase'''
        self.nombre = nombre
        self.target = target

    def start_audit(self,user,msg,name_function):

        '''Método que usa el auditor para apuntar la auditoría'''

        marcatiempos = datetime.now()
        with open('archivo_auditoría.txt','a') as auditing:

            auditing.write("//  ("
                           + marcatiempos.ctime()
                           + ")  >>>>>> [" + msg + "] at function ["
                           + name_function +"]"+ " >>>>>> Individual : " + user + "  //\n\n")
            auditing.close()

    def to_string(self):

        '''Método to string de la clase'''

        return "Nombre: " + self.nombre + ", Target: " + self.target




