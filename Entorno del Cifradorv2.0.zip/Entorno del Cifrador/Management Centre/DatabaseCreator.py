# Create a class User with attributes Username, Password, Role and activeProfile. activeProfile is boolean type.

class User:
    def __init__(self, username, password, role, activeProfile,attempts):
        self.username = username
        self.password = password
        self.role = role
        self.activeProfile = activeProfile
        self.attempts = attempts
    def __str__(self):
        return f"Username: {self.username}, Password: {self.password}, Role: {self.role}, Active Profile: {self.activeProfile}, Attempts: {self.attempts}"

# Outside of the class, create a method that writes random examples of the User class instances within a JSON file in the same directory as the script.

def writeRandomExamples():
    import json
    import random
    import string

 # Create a function that opens within the same current directory a directory called "dics" and within it, open a txt whose format of name is "X.txt" where X is a random letter from a-z, then when txt is opened, select from it a random word. Words are splitted in lines and may contain spaces or commas. Those words are not valid and selection must be done again

    def randomString():
        with open(f"dics/{random.choice(string.ascii_lowercase)}.txt") as file:
            return random.choice([line.strip() for line in file.readlines() if not line.strip().startswith(("#", ",", " "))])

    def randomBool():
        return random.choice([True, False])

    def randomRole():
       # Retorna un rol aleatorio entre Management o Squad-N, donde N es un número aleatorio entre 1 y 10
        return random.choice(["Management"] + [f"Squad-{random.randint(1, 10)}" for i in range(10)])

    def randomUser():
        return User(randomString(), randomString(), randomRole(), randomBool(),3)

    with open("users.json", "w") as file:
        json.dump([randomUser().__dict__ for i in range(10)], file)
 
# Create a menu that allows the user to choose between the following options: first option is to remove all users (Delete the file), second option is create database (call the function that creates the file), third option is to show all users (read the file and print the users), fourth option is to add an user,fourth option is to exit the program.
# Create a function that reads the file and prints all the users.

def readUsers():
    import json
    with open("users.json") as file:
        users = json.load(file)
        for user in users:
            hidden_input = "*" * len(user["password"])
            print(User(user["username"], hidden_input, user["role"], user["activeProfile"], user["attempts"]))
        print("                                                      ")
        print("                                                      ")
        print("                                                      ")

def addUser():
    import json
    import random
    import getpass

    try:
        with open("users.json") as file:
            users = json.load(file)
            username = input("Username: ")
            password = getpass.getpass(prompt="Password: ", stream = None)
            hidden_input = "*" * len(password)
            print(hidden_input)
            while True:
                print("Select role: Management or Squad")
                role = input("Role: ")
                if role.lower().__contains__("management") or role.lower().__contains__("squad"):
                        #If role is squad, then it must be followed by a random number between 1 and 10
                        if role.lower().__contains__("squad"):
                            role = f"{role}-{random.randint(1, 10)}"
                        break
                print("Please, select one role from those said")

            while True:
                print("Select Activate user or not: true or false")
                activeProfile = input("Active Profile: ")
                if activeProfile.lower().__contains__("true") or activeProfile.lower().__contains__("false"):
                        break
                print("Please, select one either true or false")
            users.append(User(username, password, role, activeProfile,3).__dict__)
        with open("users.json", "w") as file:
            json.dump(users, file)
    except FileNotFoundError:
        print("File not found, create file first...")

# Create a function that allows the user to delete the file.

def deleteFile():
    import os
    os.system("rm users.json")

# Create a function that allows the user to exit the program.

def exitProgram():
    import sys
    sys.exit()

# Create a function that allows the user to choose between the options.

def menu():
    print(" ************** WELCOME TO DATABASE MANAGER **********")
    print("                                                      ")
    while True:

        print("1. Delete all users")
        print("2. Create database")
        print("3. Show all users")
        print("4. Add an user")
        print("5. Exit the program")
        print("                                                      ")
        print("                                                      ")
        print("                                                      ")
        option = input("Choose an option: ")
        if option == "1":
            deleteFile()
        elif option == "2":
            writeRandomExamples()
        elif option == "3":

            try:
                readUsers()
            except:
                print("No users in database. Try to create")
                menu()
        elif option == "4":            
            addUser()
        elif option == "5":
            exitProgram()
        else:
            print("Invalid option")

menu()