TRIESCOUNTER = 3
ALGORITHM = ""
ROUTEUPDATES = "/home/kali/Documents/pruebas2"
ROUTEKEYLOADING = "/home/kali/Documents/pruebas"
DATABASE = "/home/kali/Entorno del Cifrador/Toy Encryptor"
ATTEMPTS = 0
ENCRYPTIONKEY = ""
SD = "NOinsert"
LIGHT = True
COMMWRITE = False
COMMSPEAK = False
NONCONCURRENTCOMS = False

def switch():

    if LIGHT == True:
        return "\033[91m"
    elif LIGHT == False:
        return "\033[30m"

def toy():
    global SD
    global LIGHT
    print("\033[38;2;0;0;1m                           ##")
    print("                           ||")
    print("\t   "+ switch()+"0\033[38;2;0;0;1m               ||")
    print("################################")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@\033[92m1.*Insert the Micro-SD*\033[38;2;0;0;1m@@@@@#")
    print("#@@\033[92m2.*Press 'Zeroize' Button*\033[38;2;0;0;1m@@#")
    print("#@@\033[92m3.*Unmount SD & Switch OFF*\033[38;2;0;0;1m@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@\033[0m"+ microsd(SD) +"\033[38;2;0;0;1m@@@@@@@@@@@#")
    print("################################\033[38;2;0;0;1m")
    print("        "+ comm() +"               "+comm()+" ")

def microsd(action):

    if action == "NOinsert":
        return "\033[0m[======]\033[30m"
    if action == "insert":
        return "\033[0m[\033[40m      \033[m]\033[30m"

def firstMenu():
    import sys
    global SD
    global LIGHT
    toy()

    while True:
        userchoice = input("\nPlease, enter a number: ")
        if userchoice == '1' or userchoice == '2' or userchoice == '3':
            break
        print("\n\033[91m Error.Invalid option \033[0m")
    if userchoice == '1':
        print("\n\033[93m  * You inserted the Micro-SD... *\033[0m")
        SD = "insert"
        toy()
        readFU()
    elif userchoice == '2':
        print("\033[93m \n* You zeroized the Toy Encryptor... *\033[0m")
        LIGHT = False
        Zeroice()
    else:
        turnOff()

def turnOff():
    global SD
    global LIGHT
    import sys
    print("\n\033[93m* Switched OFF... No more BIP BIP BOOP *\033[0m")
    LIGHT = False
    SD = "NOinsert"
    toy()
    sys.exit()

def init():
    print("\033[93m Toy Encryptor turned ON...\n * Device sounds... BIP BIP BOOP *\n")
    print(" * LED Light turned on... Device ready to use... * \n * There's not Micro-SD inserted to read yet... *")
    print("\nNow device is ready for user manipulation... What would you do? \033[0m")
    firstMenu()

def readFU():
    import os
    print("\033[93m Reading for updates...\n")
    checkForUpdates = True
    try:
        routeUpdatesList = os.listdir(ROUTEUPDATES)
        if len(routeUpdatesList) <= 0:
            print("There are no Firmware updates\033[0m")
            checkForUpdates = False

        if checkForUpdates:
            ui = 0
            for file in routeUpdatesList:
                if file.lower().__contains__(".sh"):
                    print("\033[94m ***---- PREPARING UPTADE "+ str(ui) + "----***\n")
                    updatesExec(ROUTEUPDATES, file)
                    ui += 1
            print("End of updates \033[0m\n") 
        readMI()
    except FileNotFoundError:
        print("\033 [91m Unexpected error at reading updates \033 [0m")

def updatesExec(path, file):
    import os
    import shlex
    cmd = ['./' + file]
    if os.getcwd() != path: 
        os.chdir(path)
    os.system('chmod +r ' + shlex.quote(file))
    os.system(shlex.join(cmd))
    os.remove(file)

def readMI():
    import os
    global TRIESCOUNTER
    print("\n\033[93m Reading for Missions...\n\033[91m")
    try:
        keyLoadingList = os.listdir(ROUTEKEYLOADING)
        nfiles = len(keyLoadingList)

        if nfiles <= 0:
            print("There are no keys to read. Unable to use device. \n * Micro-SD unmounted... *")
            firstMenu()
            return False
        
        for file in keyLoadingList:
            nfiles -= 1
            verifyLogin = False
            if file.lower().__contains__(".json"):
                auxPath = ROUTEKEYLOADING + "/" + file
                verifyLogin = logIn(auxPath)
                
                if verifyLogin is True:
                    TRIESCOUNTER = 3
                    break
                
                if TRIESCOUNTER <= 0:
                    print("\nERROR! ERROR! DETECTED INTRUDER. STARTING SECURITY PROCEDURE\n")
                    erase = os.listdir(ROUTEKEYLOADING)
                    if len(erase) > 0:
                        for auxPath in erase:
                            eraseKeys = ROUTEKEYLOADING + "/" + auxPath
                            toast(eraseKeys)
                        break #Intentional jump here
                    #Exploit : Never Ends execution afer toasting, 
                    # access to comms without key. Just stops reading credentials after having deleted (BAD CODE). 
                    # Now Key is none, comms are wit1hout encrypting

                if nfiles == 0 and TRIESCOUNTER > 0:
                    print("Could not verify credentials credentials for Encryptor Usage")
                    return False
        commsMenu()
    except FileNotFoundError:
        print("Unexpected error reading keys")

def commsMenu():
    global COMMWRITE,COMMSPEAK,NONCONCURRENTCOMS
    print("\033[38;5;129m Algorithm: -> " + ALGORITHM + " <-\033[0m")
    print("\033[38;5;129m With Key: -> " + ENCRYPTIONKEY + " <-\033[0m")
    print("\n\033[93m* Communications are ready. Device waiting for user action... \033[0m*\n")
    while True:
        userinput = input("\033[92m1. * Turn on and attach the computer to write a message for the squad (Lights YELLOW left LED)*\n2. "
                      + "* Turn on and attach the walkie-talkie to send voice message to the squad (Lights BLUE Right LED) *\n3. * Leave communications * ")
        if userinput == '1' or userinput == '2' or userinput == '3':
            break
        print("\033[91m \nInvalid action for comms system\033[0m")

    if userinput == '1':
        print("\033[93m * Click! - Attached computer to encryptor. \nTurned on... * ")
        COMMWRITE = True
        toy()
        commsWrite()
    elif userinput == '2':
        print("\033[93m * Click! - Attached walkie-talkie to encryptor. \nTurned on... * ")
        NONCONCURRENTCOMS = True
        COMMSPEAK = True
        toy()
        commsVoice()
    else:
        firstMenu()

def comm():

    global COMMSPEAK,COMMWRITE,NONCONCURRENTCOMS

    if NONCONCURRENTCOMS == True:
        NONCONCURRENTCOMS = False
        return "\033[30m0"
    
    if COMMSPEAK == True and COMMWRITE == False:
        COMMWRITE = False
        COMMWRITE = False
        return "\033[38;2;0;128;255m0\033[m"
    
    if COMMWRITE == True and COMMSPEAK == False:
        COMMWRITE= False
        COMMSPEAK = False
        return "\033[38;2;255;255;0m0\033[m"
    
    return "\033[38;2;0;0;1m0"

def commsWrite():
    global COMMWRITE
    while True:
        respuesta = input("Do you want to send other written message? (y/n): ")
        if respuesta.lower() == "n":
            COMMWRITE = False
            commsMenu()
        elif respuesta.lower() == "y":
            print("Continuando con el programa...")
        else:
            print("Respuesta no válida. Intente de nuevo.")

def commsVoice():
    global COMMSPEAK
    while True:
        respuesta = input("Do you want to send other voice message? (y/n): ")
        if respuesta.lower() == "n":
            COMMSPEAK = False
            commsMenu()
        elif respuesta.lower() == "y":
            print("Continuando con el programa...")
        else:
            print("Respuesta no válida. Intente de nuevo.")

def Zeroice():
    import os
    import sys
    global SD
    try:
        keyLoadingList = os.listdir(ROUTEKEYLOADING)
        if len(keyLoadingList) > 0:
            for file in keyLoadingList:
                if file.lower().__contains__(".json"):
                    auxPath = ROUTEKEYLOADING + "/" + file
                    toast(auxPath)
            toy()
            print("\033[93m Zeroized device... Useless Toy Now.. Switching OFF!")
            print("* STOPPED BIP BIP BOOP * \033[0m")
            sys.exit()
        else:
            toy()
            print("\033[93m * Nothing happened *\033[0m")                              
    except FileNotFoundError:
        print(" \033[91m Unexpected error zeroizing!! \033[0m")

def toast(path):
    import os
    global ALGORITHM
    ALGORITHM = ""

    os.remove(path) # Limpiando json file to empty

    # Limpia datos de firmware updates si los hay
    aLimpiar = os.listdir(ROUTEUPDATES)
    if len(aLimpiar) > 0:
        for file in aLimpiar:
            auxPath = ROUTEUPDATES + "/" + file
            os.remove(auxPath) 

def verifySquad(squad):

    number = squad.split("-")[1]

    if int(number) in range(11):
        return True
    
    return False

def readDB():
        import shlex
        import os
        import json
        names=[]
        retdir = os.getcwd()
        if os.getcwd() != DATABASE: 
            os.chdir(DATABASE)
        os.system('chmod +r ' + shlex.quote('users.json'))

        with open("users.json","r") as file:
            usersDatabase = json.load(file)
            file.close()
            for auxuser in usersDatabase:
                names.append(auxuser["username"])

        os.chdir(retdir)
        return  names 
def logIn(auxPath):
    global TRIESCOUNTER
    global ATTEMPTS
    try:
        import json
       
        with open(auxPath,"r") as file:
            user = json.load(file)
            file.close()           
            if len(user["username"]) <= 0 or len(user["role"]) <= 0  or len(user["key"]) <= 0 or len(user["algorithm"]) <= 0:
                raise Exception()
        
        names = readDB()
        
        if not user["username"] in names:
                print("Unexistent user the one loaded at Micro-SD credentials")
                raise Exception()
        
        if not user["role"].lower().__contains__("squad"):
            print("User is not part of the Mission. Does not belong to any squad")
            raise Exception()
        elif not verifySquad(user["role"]):
            print("Unexistent squad. Could not verify.")
            raise Exception()
        
        return setEncryptorKey(user["algorithm"],user["key"])
    except Exception:
        ATTEMPTS += 1
        TRIESCOUNTER -= 1
        print("There was a problem reading credentials. Attempt -> "+ str(ATTEMPTS)) 

def setEncryptorKey(algorithm,key):
    global ALGORITHM
    global ENCRYPTIONKEY
    if len(algorithm) > 0 and len(key) > 0:
        ALGORITHM = algorithm
        ENCRYPTIONKEY = key
        return True
    
    return False

init()