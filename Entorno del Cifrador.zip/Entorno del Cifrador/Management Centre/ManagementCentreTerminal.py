RUTAMOUNT = "/sd"
RUTADB = RUTAMOUNT + "/Database"
RUTAUPDATES = RUTAMOUNT+"/Updates"
RUTAMISSIONS = RUTAMOUNT+"/Missions"
NAME = ""
# Create a function called mainMenu that at first, welcomes the user by the username given as input. Then, it gives 2 options. Update Firmware or Charge Encoding algorithm.

def SDmount():
    # Mount the SD Card using micropython
    #import micropython
    from micropython import machine

    # Mount the SD card
    try:
        sd = machine.SDCard(slot=3, width=1, sck=machine.Pin(14), mosi=machine.Pin(13), miso=machine.Pin(12), cs=machine.Pin(15))
        import os
        #Montar la SD y guardar la ruta en RUTAMOUNT
        os.mount(sd, RUTAMOUNT)
        print("\033[93mSD card mounted successfully\033[0m")
        return True
    except:
        print("\033[91mSD card not mounted\033[0m")
        return False
    

def SDumount(): 
    # Unmount the SD Card using micropython
    #import micropython
    from micropython import machine
    # Unmount the SD card
    try:
        sd = machine.SDCard(slot=3, width=1, sck=machine.Pin(14), mosi=machine.Pin(13), miso=machine.Pin(12), cs=machine.Pin(15))
        import os
        #Desmontar la SD y guardar la ruta en RUTAMOUNT
        os.umount(RUTAMOUNT)
        print("\033[93mSD card unmounted successfully\033[0m")
        return True
    except:
        print("\033[91mSD card not unmounted\033[0m")
        return False

def mainMenu(username):
    print("\033[93m_______________________________________________")
    print("/                                               \\")
    print("|   ******************************************  |")
    print("|   *          \033[94mUser : "+ NAME + "               \033[92m*   |")
    print("|   *          \033[92m1. Update Firmware           *   |")
    print("|   *          2. Charge Encoding algorithm *   |")
    print("|   *          3. Exit\033[93m                      *   |")
    print("|    *****************************************  |")
    print("\\______________________________________________/")
    print("                |                 | ")
    print("                |                 | ")

    try:
        option = input("Please select an option: ")
        if option == "1":
            SDmount()
            updateFirmware()
            SDumount()
            mainMenu(username)
        elif option == "2":
            SDmount()
            chargeEncodingalgorithm()
            SDumount()
            mainMenu(username)
        elif option == "3":
            username = ""
            initMenu()
        else:
            print("\033[91mInvalid option\033[0m")
            mainMenu(username)
    except:
        print("Unexpected Exception (Probably due to MicroSD accessing)")
        mainMenu(username)

def updateFirmware():
# Open a script to write within it
    import os
    script = open("updateFirmware.sh", "w")
    script.write("""#!/bin/bash

# Simulación de carga con una barra de ASCII

# Número de iteraciones
n=10

echo "Firmware loading..."

# Bucle de simulación de carga
for i in $(seq 1 $n)
do
  # Simulación de proceso
  sleep 1

  # Cálculo de progreso
  progress=$((i * 100 / n))

  # Impresión de barra de ASCII
  echo -ne "Progress: [$((i * 10))%] ["
  for ((j=0; j<$i; j++))
  do
    echo -ne "#"
  done
  for ((j=$i; j<$n; j++))
  do
    echo -ne "-"
  done
  echo -ne "]"
  echo -ne " ($progress%)\r"
done

echo -e "\n Firmware loading completed."
""")
    script.close() 
    # Give the script execution permissions
    print("\033[91m")
    os.system("chmod +x updateFirmware.sh")
# Move the script to the directory where it will be stored, which is an external SD card
    os.system("mv updateFirmware.sh " + RUTAUPDATES)
# Give the script permissions to be executed
    os.system("chmod +x "+ RUTAUPDATES + "/updateFirmware.sh")
    print("\033[93m")

def chargeEncodingalgorithm():
    import json
    import os
    import getpass
# Ask the user for the username of the person who is assigned to the mission
    username = input("Please enter the username of the person who is assigned to the mission: ")
    n_squad = input("Please enter the number of the squad carring out the mission: ")
    # Search the user in "users.json" file. If the user exists, check if role contains "squad". If it contains it, compare the number of the squad with the input number given.
    with open("users.json", "r") as file:
        users = json.load(file)
        for user in users:
            if user["username"] == username:
                if user["role"].lower().__contains__("squad"):
                    if user["role"].lower().__contains__(n_squad):
                        # call method selectalgorithm() and store it into a variable
                        algorithm = selectalgorithm()
                        key = getpass.getpass("\nPlease, discretely enter the key: ")
                        #  Write in a json file named "SDInfo.json" the username and the role with the number of the squad added to it, separated by "-"
                        with open("SDInfo.json", "w") as file:
                            json.dump({"username": username, "role": user["role"], "algorithm": algorithm, "key" : key}, file)
                        # Move the file to the directory where it will be stored, which is an external SD card
                        print("\033[91m")
                        os.system("mv SDInfo.json "+ RUTAMISSIONS)
                        os.system("mv users.json "+ RUTAMISSIONS)
                        # Give the file permissions to be read
                        os.system("chmod +r "+ RUTAMISSIONS +"/SDInfo.json")
                        os.system("chmod +r "+ RUTADB + "/users.json")
                        print("\033[93mThe algorithm has been successfully stored in the SD card")
                        return True
                        
                    else:
                        print("\033[91mThe user is not in the squad number given. Canceling operation...\033[0m")
                        return False
                else:
                    print("\033[91mThe user is not in the squad.Canceling operation...\033[0m")
                    return False
        else:
            print("\033[91mThat user does not exist.Canceling operation...\033[0m")
            return False

# Create a function called InitMenu that gives the user two possibilities: login or exit the program.
def initMenu():
    import getpass
    print("\n\n")
    print("\033[93m_______________________________________________")
    print("|                                               \\")
    print("|    *****************************************  |")
    print("|    *      Welcome to the MC Terminal       *  |")
    print("|    *            \033[92m1. Log In                  *  |")
    print("|    *            2. Exit\033[93m                    *  |")
    print("|    *****************************************  |")
    print("\\______________________________________________/")
    print("                |                 | ")
    print("                |                 | \n\n\033[93m")

    option = input("Please select an option: ")
    if option == "1":
        # Ask for continue with login each time a wrong user or password is entered
        while True:
            username = input("\033[93mPlease enter your username: ")
            password = getpass.getpass(prompt="Please enter your password: ", stream = None)
            if logIn(username, password):
                break
                # ask in loop if user wants to continue with login
            while True:
                continueLogin = input("Do you want to continue with login? (y/n): ")
                if continueLogin == "y":
                    break
                elif continueLogin == "n":
                    initMenu()
                else:
                    print("\033[91mInvalid option\033[93m")
        
        
    elif option == "2":
        print("_______________________________________________")    
        print("/                                               \\")
        print("|    *****************************************  |")
        print("|    *          \033[92mThanks for using MC          *  |")
        print("|    *                Terminal\033[93m               *  |")
        print("|    *****************************************  |")
        print("\\______________________________________________/")
        print("                |                 | ")
        print("                |                 | ")
    else:
        print("Invalid option")
        initMenu()


def logIn(username, password):
# Read "users.json" file. For each user in the file, if any user matches with the username, check if activeProfile is false and attempts lower or equal to 0 to return False. If not, check both passwords. If password is incorrect, substract one attempt, store the user in the file and return false. If password is correct, return true.
    import json
    global NAME
    with open("Entorno del Cifrador/Management Centre/users.json", "r") as file:
        users = json.load(file)
        print("\n\033[91m")
        for user in users:
            if user["username"] == username:
                if user["activeProfile"] == False or user["attempts"] <= 0:
                    print("Your account is blocked. Please contact your administrator")
                    return False
                if not user["role"].lower().__contains__("management"):
                    print("You don't have permission to access this terminal")
                    return False
                else:
                    if user["password"] == password:
                        user["activeProfile"] = True
                        user["attempts"] = 3
                        with open("users.json", "w") as file:
                            json.dump(users, file)
                        NAME = username
                        mainMenu(username)
                        return True
                    else:
                        user["attempts"] -= 1
                        if user["attempts"] <= 0:
                            user["activeProfile"] = False
                            print("Ask your administrator to unblock your account")
                            with open("users.json", "w") as file:
                                json.dump(users, file)
                            return False
                        print("Incorrect password. You have " + str(user["attempts"]) + " attempts left")
                        with open("users.json", "w") as file:
                            json.dump(users, file)
                        return False
        print("User not found\033[93m")
        return False

def selectalgorithm():
    import sys        
    exit = True
    algorithm = ""

    while exit:
            exit = False
            sys.stdin.flush()
            option = input("\nPlease, select the algorithm for the mission from the following. The first algorithm selected will be assigned to the mission.\n"+
                           "algorithm ROT13\nalgorithm ROT47\nalgorithm XOR\nalgorithm RC4\nalgorithm AES-ECB\nalgorithm 3DES\nalgorithm Vigenere\nalgorithm Bifid\n")
            if option.upper().__contains__("ROT13"):
                algorithm = "ROT13"
            elif option.upper().__contains__("ROT47"):
                algorithm = "ROT47"
            elif option.upper().__contains__("XOR"):
                algorithm = "XOR"
            elif option.upper().__contains__("RC4"):
                algorithm = "RC4"
            elif option.upper().__contains__("AES-ECB"):
                algorithm = "AES-ECB"
            elif option.upper().__contains__("3DES"):
                algorithm = "3DES"
            elif option.upper().__contains__("Vigenere"):
                algorithm = "Vigenere"
            elif option.upper().__contains__("Bifid"):
                algorithm = "Bifid"
            else:
                while True:
                    print("Invalid option. Do you want to stop algorithm selection? (y/n): ")
                    sys.stdin.flush()
                    option2 = input()
                    if option2 == "y":
                        if len(algorithm) <= 0:
                            print("You have to chose algoritm. Mandatory selection")
                            exit = True
                            break
                        break
                    elif option2 == "n":
                        exit = True
                        break
                    else:
                        print("Invalid option")
    return algorithm

initMenu()

