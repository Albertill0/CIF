Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/sd_read_simpletest.py
    :caption: examples/sd_read_simpletest.py
    :linenos:
