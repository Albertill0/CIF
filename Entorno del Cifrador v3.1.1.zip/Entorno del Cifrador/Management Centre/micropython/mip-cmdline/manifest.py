metadata(version="0.1.0", description="Optional support for running `micropython -m mip`")

require("argparse")
require("mip")

package("mip")
