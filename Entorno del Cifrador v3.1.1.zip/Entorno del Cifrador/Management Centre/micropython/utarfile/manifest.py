metadata(description="Lightweight tarfile module subset", version="0.3.2")

# Originally written by Paul Sokolovsky.

module("utarfile.py")
