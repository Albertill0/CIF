metadata(
    version="0.1",
    description="Provides a minimal ESP32 bootloader protocol implementation.",
)

module("espflash.py")
