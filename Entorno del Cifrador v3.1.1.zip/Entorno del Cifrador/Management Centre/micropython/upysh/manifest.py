metadata(description="Minimalistic file shell using native Python syntax.", version="0.6.1")

module("upysh.py")
