## MicroPython-specific packages

These are packages that have been written specifically for use on MicroPython.

Packages in this directory should not have the same name as modules from the Python Standard Library.

### Future plans

* More organised directory structure based on purpose (e.g. drivers, network, etc).
