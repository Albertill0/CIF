metadata(version="0.2.0")

require("aioble-core")

package("aioble", files=("peripheral.py",), base_path="../aioble")
