metadata(version="0.2.1")

require("aioble-core")

package("aioble", files=("central.py",), base_path="../aioble")
