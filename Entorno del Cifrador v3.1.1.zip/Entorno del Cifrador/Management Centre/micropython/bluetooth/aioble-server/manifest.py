metadata(version="0.3.0")

require("aioble-core")

package("aioble", files=("server.py",), base_path="../aioble")
