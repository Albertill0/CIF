metadata(
    description="SenML serialisation for MicroPython.",
    version="0.1.0",
    pypi_publish="micropython-senml",
)

require("cbor2")

package("senml")
