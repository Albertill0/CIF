
# senml_base Module


## senml_base.SenmlBase Objects


the base class for all senml objects. 
