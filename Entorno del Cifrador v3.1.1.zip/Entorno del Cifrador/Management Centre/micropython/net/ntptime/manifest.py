metadata(description="NTP client.", version="0.1.0")

module("ntptime.py", opt=3)
