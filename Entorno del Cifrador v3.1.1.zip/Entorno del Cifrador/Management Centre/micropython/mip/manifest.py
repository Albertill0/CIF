metadata(version="0.2.0", description="On-device package installer for network-capable boards")

require("urequests")

package("mip", opt=3)
