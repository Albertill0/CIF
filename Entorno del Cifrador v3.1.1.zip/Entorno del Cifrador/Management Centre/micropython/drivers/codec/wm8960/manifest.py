metadata(description="WM8960 codec.", version="0.1.0")

module("wm8960.py", opt=3)
