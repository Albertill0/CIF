metadata(description="nrf24l01 2.4GHz radio driver.", version="0.1.0")

module("nrf24l01.py", opt=3)
