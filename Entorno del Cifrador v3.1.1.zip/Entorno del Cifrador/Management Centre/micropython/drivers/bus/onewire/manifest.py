metadata(description="Onewire driver.", version="0.1.0")

module("onewire.py", opt=3)
