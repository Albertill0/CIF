metadata(description="SDCard block device driver.", version="0.1.0")

module("sdcard.py", opt=3)
