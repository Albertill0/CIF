metadata(description="Driver for ST LSM9DS1 IMU.", version="1.0.0")
module("lsm9ds1.py", opt=3)
