metadata(description="BOSCH BMM150 magnetometer driver.", version="1.0.0")
module("bmm150.py", opt=3)
