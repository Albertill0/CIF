metadata(description="ST LSM6DSOX imu driver.", version="1.0.0")
module("lsm6dsox.py", opt=3)
