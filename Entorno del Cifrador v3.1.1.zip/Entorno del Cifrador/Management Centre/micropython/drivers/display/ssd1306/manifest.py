metadata(description="SSD1306 OLED driver.", version="0.1.0")

module("ssd1306.py", opt=3)
