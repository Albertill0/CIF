metadata(description="DS18x20 temperature sensor driver.", version="0.1.0")

require("onewire")
module("ds18x20.py", opt=3)
