metadata(description="LPS22H temperature/pressure sensor driver.", version="0.1.0")

module("lps22h.py", opt=3)
