metadata(
    version="0.1.0",
    description="Common networking packages for all network-capable deployments of MicroPython.",
)

require("mip")
require("ntptime")
require("urequests")
require("webrepl")
