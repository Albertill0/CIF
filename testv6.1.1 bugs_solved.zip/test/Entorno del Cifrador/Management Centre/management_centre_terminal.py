'''Módulo para el manejo del MC'''
import sys
import os
import getpass
import json
from micro_sd import SdCard

# pylint: disable=C0301
# pylint: disable=C2801
# pylint: disable=W1514
# pylint: disable=R1732

class ManagementCentre():

    '''Clase para instanciar el ordenador de management'''

    RUTAMOUNT = "/mnt"
    RUTADB = "/Database"
    RUTAUPDATES = "/Updates"
    RUTAMISSIONS = "/Missions"
    NAME = ""
    MICRO_SD = SdCard("microSD", "8GB", "FAT32")

    def __init__(self, tipo, target):
        '''Constructor de la clase'''
        self.tipo = tipo
        self.target = target

    def to_string(self):
        '''Método to string de la clase'''
        return "Tipo: " + self.tipo + "Target: " + self.target

    def __main_menu(self,username):
        '''Método para el mmenú de manejo del cifrador'''

        print("\033[93m_______________________________________________")
        print("/                                               \\")
        print("|   ******************************************  |")
        print("|   *          \033[94mUser : " + ManagementCentre.NAME + "               \033[92m*   |")
        print("|   *          \033[92m1. Update Firmware           *   |")
        print("|   *          2. Charge Encoding algorithm *   |")
        print("|   *          3. Exit\033[93m                      *   |")
        print("|    *****************************************  |")
        print("\\______________________________________________/")
        print("                |                 | ")
        print("                |                 | ")

        try:
            option = input("Please select an option: ")
            if option == "1":
                possibleunmount = ManagementCentre.MICRO_SD.sd_mount(ManagementCentre.RUTAMOUNT)
                if possibleunmount:
                    self.__update_firmware()
                    ManagementCentre.MICRO_SD.sd_umount(ManagementCentre.RUTAMOUNT)
                self.__main_menu(username)
            elif option == "2":
                possibleunmount = ManagementCentre.MICRO_SD.sd_mount(ManagementCentre.RUTAMOUNT)
                if possibleunmount:
                    self.__charge_encoding_algorithm()
                    ManagementCentre.MICRO_SD.sd_umount(ManagementCentre.RUTAMOUNT)
                self.__main_menu(username)
            elif option == "3":
                username = ""
                self.init_menu()
            else:
                print("\033[91mInvalid option\033[0m")
                self.__main_menu(username)
        except IOError:
            print("Unexpected Exception (Probably due to MicroSD accessing)")
            self.__main_menu(username)


    def __update_firmware(self):
        '''Método para actualizar al firmware'''

        script = open("update_firmware.sh", "w")
        script.write(
            """#!/bin/bash

    # Simulación de carga con una barra de ASCII

    # Número de iteraciones
    n=10

    echo "Firmware loading..."

    # Bucle de simulación de carga
    for i in $(seq 1 $n)
    do
    # Simulación de proceso
    sleep 1

    # Cálculo de progreso
    progress=$((i * 100 / n))

    # Impresión de barra de ASCII
    echo -ne "Progress: [$((i * 10))%] ["
    for ((j=0; j<$i; j++))
    do
        echo -ne "#"
    done
    for ((j=$i; j<$n; j++))
    do
        echo -ne "-"
    done
    echo -ne "]"
    echo -ne " ($progress%)\r"
    done

    echo -e "\n Firmware loading completed."
    """
        )
        script.close()
        # Give the script execution permissions
        print("\033[91m")
        os.system("sudo chmod +x update_firmware.sh")
        # Move the script to the directory where it will be stored, which is an external SD card
        os.system("sudo cp update_firmware.sh " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTAUPDATES)
        # Give the script permissions to be executed
        os.system("sudo chmod +x " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTAUPDATES + "/update_firmware.sh")
        print("\033[93m")


    def __charge_encoding_algorithm(self):
        '''Método que permite cambiar el algoritmo para encriptar'''

        username = input(
            "\n\nPlease enter the username of the person who is assigned to the mission: "
        )
        n_squad = input("Please enter the number of the squad carring out the mission: ")
        print("\n")

        with open("users.json", "r") as file:
            users = json.load(file)
            for user in users:
                if user["username"] == username:
                    if user["role"].lower().__contains__("squad"):
                        if user["role"].lower().__contains__(n_squad):
                            algorithm = self.__select_algorithm()
                            key = ""
                            if algorithm in (
                                "XOR",
                                "RC4",
                                "AES-ECB",
                                "3DES",
                                "Vigenere",
                                "Bifid",
                            ):
                                key = getpass.getpass(
                                    "\nPlease, discretely enter the key: "
                                )

                            with open("SDInfo.json", "w") as file:
                                json.dump(
                                    {
                                        "username": username,
                                        "role": user["role"],
                                        "algorithm": algorithm,
                                        "key": key,
                                    },
                                    file,
                                )
                            print("\033[91m")
                            os.system("sudo cp SDInfo.json " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTAMISSIONS)
                            os.system("sudo cp users.json " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTADB)
                            os.system(
                                "sudo chmod +r " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTAMISSIONS + "/SDInfo.json"
                            )
                            os.system("sudo chmod +r " + ManagementCentre.RUTAMOUNT + ManagementCentre.RUTADB + "/users.json")
                            print(
                                "\033[93mThe algorithm has been successfully stored in the SD card"
                            )
                            return True            
                        print(
                            "\033[91mThe user is not in the squad number given. Canceling operation...\033[0m"
                        )
                        return False
                    print(
                        "\033[91mThe user is not in the squad.Canceling operation...\033[0m"
                    )
                    return False
            print("\033[91mThat user does not exist.Canceling operation...\033[0m")
            return False

    def init_menu(self):
        '''Método de inicio de la clase MC'''

        print("\n\n")
        print("\033[93m_______________________________________________")
        print("|                                               \\")
        print("|    *****************************************  |")
        print("|    *      Welcome to the MC Terminal       *  |")
        print("|    *            \033[92m1. Log In                  *  |")
        print("|    *            2. Exit\033[93m                    *  |")
        print("|    *****************************************  |")
        print("\\______________________________________________/")
        print("                |                 | ")
        print("                |                 | \n\n\033[93m")

        option = input("Please select an option: ")
        if option == "1":

            while True:
                username = input("\033[93mPlease enter your username: ")
                password = getpass.getpass(
                    prompt="Please enter your password: ", stream=None
                )
                if self.__log_in(username, password):
                    break

                while True:
                    continue_login = input("Do you want to continue with login? (y/n): ")

                    if continue_login == "y":
                        break
                    elif continue_login == "n":
                        self.init_menu()
                        return False
                    print("\033[91mInvalid option\033[93m")

        elif option == "2":
            print("_______________________________________________")
            print("/                                               \\")
            print("|    *****************************************  |")
            print("|    *          \033[92mThanks for using MC          *  |")
            print("|    *                Terminal\033[93m               *  |")
            print("|    *****************************************  |")
            print("\\______________________________________________/")
            print("                |                 | ")
            print("                |                 | ")
        else:
            print("Invalid option")
            self.init_menu()

    def __log_in(self,username, password):
        '''Método de inicio de sesión'''

        with open("users.json", "r") as file:
            users = json.load(file)
            print("\n\033[91m")
            for user in users:
                if user["username"] == username:
                    if user["active_profile"] is False or user["attempts"] <= 0:
                        print("Your account is blocked. Please contact your administrator")
                        return False
                    if not user["role"].lower().__contains__("management"):
                        print("You don't have permission to access this terminal")
                        return False
                    else:
                        if user["password"] == password:
                            user["active_profile"] = True
                            user["attempts"] = 3
                            with open("users.json", "w") as file:
                                json.dump(users, file)
                            ManagementCentre.NAME = username
                            self.__main_menu(username)
                            return True
                        else:
                            user["attempts"] -= 1
                            if user["attempts"] <= 0:
                                user["active_profile"] = False
                                print("Ask your administrator to unblock your account")
                                with open("users.json", "w") as file:
                                    json.dump(users, file)
                                return False
                            print(
                                "Incorrect password. You have "
                                + str(user["attempts"])
                                + " attempts left"
                            )
                            with open("users.json", "w") as file:
                                json.dump(users, file)
                            return False
            print("User not found\033[93m")
            return False

    def __select_algorithm(self):
        '''Método para seleccionar algoritmo de encryptado'''

        leave = True
        algorithm = ""

        while leave:
            leave = False
            sys.stdin.flush()
            option = input(
                "\nPlease, select the algorithm for the mission from the following.\nThe first algorithm selected will be assigned to the mission.\n\n"
                + "algorithm ROT13\nalgorithm ROT47\nalgorithm XOR\nalgorithm RC4\nalgorithm AES-ECB\nalgorithm 3DES\nalgorithm Vigenere\nalgorithm Bifid\n"
            )
            if option.upper().__contains__("ROT13"):
                algorithm = "ROT13"
            elif option.upper().__contains__("ROT47"):
                algorithm = "ROT47"
            elif option.upper().__contains__("XOR"):
                algorithm = "XOR"
            elif option.upper().__contains__("RC4"):
                algorithm = "RC4"
            elif option.upper().__contains__("AES-ECB"):
                algorithm = "AES-ECB"
            elif option.upper().__contains__("3DES"):
                algorithm = "3DES"
            elif option.upper().__contains__("VIGENERE"):
                algorithm = "Vigenere"
            elif option.upper().__contains__("BIFID"):
                algorithm = "Bifid"
            else:
                while True:
                    print(
                        "Invalid option. Do you want to stop algorithm selection? (y/n): "
                    )
                    sys.stdin.flush()
                    option2 = input()
                    if option2 == "y":
                        if len(algorithm) <= 0:
                            print("You have to chose algoritm. Mandatory selection")
                            leave = True
                            break
                        break
                    elif option2 == "n":
                        leave = True
                        break
                    else:
                        print("Invalid option")
        return algorithm

mc = ManagementCentre("Ordenador de control", "Seguridad")
mc.init_menu()
