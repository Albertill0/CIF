# Crea la clase SD
class SDCard:
    # Create a init method that initializes the attributes of the class
    def __init__(self, name, size, type):
        self.name = name
        self.size = size
        self.type = type

    def SDmount(self, route):
        # Mount the SD card dinamically if not mounted yet
        import os

        try:
            if os.path.ismount(route):
                print("\033[93mSD card already mounted\033[0m")
                return True
            print("\033[93mMounting SD card...")
            # Mount the SD card with rw permissions
            code = os.system("sudo mount -o rwx /dev/mmcblk0p2 " + route)
            if code != 0:
                print("\033[91mSD card impossible to be mounted\033[0m")
                return False
            print("Inserted SD FAT32 Card of type: -> " + self.__str__())
            print("SD card mounted successfully\033[0m")
            return True
        except:
            print("\033[91mUnexpected exception\033[0m")
            return False

    def SDumount(self, route):
        # Unmount the SD card dinamically if mounted
        import os
        import time

        # wait 5 seconds
        print("\033[93mWaiting 3 seconds to complete card reading...\033[0m")
        time.sleep(3)
        try:
            if not os.path.ismount(route):
                print("\033[93mSD card impossible to be unmounted\033[0m")
                return True
            print("\033[93mUnmounting SD card...")
            code = os.system("sudo umount -l " + route)
            if code != 0:
                print("\033[91mSD card impossible to be unmounted\033[0m")
                return False
            print("SD card unmounted successfully\033[0m")
            return True
        except:
            print("\033[91mUnexpected exception\033[0m")
            return False

    # create print method
    def __str__(self):
        return "Name: " + self.name + "\nSize: " + self.size + "\nType: " + self.type
