import unittest
import os
import sys
import json
import getpass
import random


# Create a logInTest method to test the logIn() method from ManagementCentreTerminal.py
class ManagementCentreTests(unittest.TestCase):
    # Create a username and password to try the method
    username = "Alberto"
    password = "Manolo"

    # Use try catch and call the method logIn() from ManagementCentreTerminal.py
    def test_logInCorrect(self):
        try:
            from ManagementCentreTerminal import logIn

            logIn(self.username, self.password)
        except ImportError:
            self.fail("Could not import logIn")
        except:
            self.fail("logIn raised an Exception unexpectedly!. Could not logIn")

    # Create a method to test the logIn() method with a wrong username
    def test_logIn_wrong_username(self):
        try:
            from ManagementCentreTerminal import logIn

            logIn("wrong_username", self.password)
        except ImportError:
            self.fail("Could not import logIn")
        except:
            self.fail(
                "logIn raised an Exception. Could not logIn due to wrong username"
            )

    # Create a method to test the logIn() method with a wrong password
    def test_logIn_wrong_password(self):
        try:
            from ManagementCentreTerminal import logIn

            logIn(self.username, "wrong_password")
        except ImportError:
            self.fail("Could not import logIn")
        except:
            self.fail(
                "logIn raised an Exception. Could not logIn due to wrong password"
            )

    # Create a method to test the logIn() method with a correct username and password but user role is not management
    def test_logIn_wrong_role(self):
        try:
            from ManagementCentreTerminal import logIn

            logIn(
                self.username + "Combatiente", "AnyPassword"
            )  # The role for this user is not management
        except ImportError:
            self.fail("Could not import logIn")
        except:
            self.fail("logIn raised an Exception. Could not logIn due to wrong role")

    # Create a method to test the logIn() method with a correct username and password but user has no attempts left.
    def test_logIn_no_attempts(self):
        try:
            from ManagementCentreTerminal import logIn

            logIn(
                self.username + "NoAttempts", "AnyPassword"
            )  # The user has no attempts left
        except ImportError:
            self.fail("Could not import logIn")
        except:
            self.fail(
                "logIn raised an Exception. Could not logIn due to having no attempts left"
            )

    # Create a method to test UpdateFirmware() method from ManagementCentreTerminal.py
    def test_updateFirmware(self):
        try:
            from ManagementCentreTerminal import updateFirmware

            updateFirmware()
        except ImportError:
            self.fail("Could not import updateFirmware")
        except:
            self.fail(
                "updateFirmware raised an Exception unexpectedly!. Could not update firmware"
            )


# Create a class to test the DatabaseCreator.py
class DatabaseCreatorTests(unittest.TestCase):
    # Create a function to test the readUsers() method from DatabaseCreator.py
    def test_readUsers(self):
        try:
            from DatabaseCreator import readUsers

            readUsers()
        except ImportError:
            self.fail("Could not import readUsers")
        except:
            self.fail(
                "readUsers raised an Exception unexpectedly!. Could not read users"
            )

    # Create a function to test the WriteRandomExamples() method from DatabaseCreator.py
    def test_writeRandomExamples(self):
        try:
            from DatabaseCreator import writeRandomExamples

            writeRandomExamples()
        except ImportError:
            self.fail("Could not import writeRandomExamples")
        except:
            self.fail(
                "writeRandomExamples raised an Exception unexpectedly!. Could not write random examples"
            )

    # Create a function to test the deleteFile() method from DatabaseCreator.py
    def test_deleteFile(self):
        try:
            from DatabaseCreator import deleteFile

            deleteFile()
        except ImportError:
            self.fail("Could not import deleteFile")
        except:
            self.fail(
                "deleteFile raised an Exception unexpectedly!. Could not delete file"
            )

    # Create a function to test the exitProgram() method from DatabaseCreator.py
    def test_exitProgram(self):
        try:
            from DatabaseCreator import exitProgram

            exitProgram()
        except ImportError:
            self.fail("Could not import exitProgram")
        except:
            self.fail(
                "exitProgram raised an Exception unexpectedly!. Could not exit program"
            )
