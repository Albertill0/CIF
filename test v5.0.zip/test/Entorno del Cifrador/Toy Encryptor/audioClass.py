class walkieTalkie:
    def __init__(self, type, band, channel, frequency):
        self.type = type
        self.band = band
        self.channel = channel
        self.frequency = frequency

    def __str__(self):
        return (
            "Type: "
            + self.type
            + "\nBand: "
            + self.band
            + "\nChannel: "
            + self.channel
            + "\nFrequency: "
            + self.frequency
        )

    def record(self, inp):
        import sounddevice as sd

        duration = 10
        sample_rate = 44100
        device_index = inp

        audio = sd.InputStream(
            samplerate=sample_rate, device=device_index, channels=2, dtype="int16"
        )

        audio.start()
        print("Recording...")
        print("Recording done!")
        audio.stop()
        audio_data = audio.read(audio)

        return audio_data
