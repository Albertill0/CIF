from ClaseSD import SDCard
from Encryptors import Encryptor

TRIESCOUNTER = 3
ALGORITHM = ""
RUTASD = "/mnt"
ROUTEUPDATES = RUTASD + "/Updates"
ROUTEKEYLOADING = RUTASD + "/Missions"
DATABASE = RUTASD + "/Database"  # Esto luego lee de la ruta de SD correspondiente
ATTEMPTS = 0
ENCRYPTIONKEY = ""
SD = "NOinsert"
LIGHT = True
COMMWRITE = False
COMMSPEAK = False
NONCONCURRENTCOMS = False
COMBATIENT = ""


def switch():
    if LIGHT == True:
        return "\033[91m"
    elif LIGHT == False:
        return "\033[30m"


def toy():
    global SD
    global LIGHT
    print("\n\n\033[38;2;0;0;1m                           ##")
    print("                           ||")
    print("\t   " + switch() + "0\033[38;2;0;0;1m               ||")
    print("################################")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@\033[92m1.*Insert the Micro-SD*\033[38;2;0;0;1m@@@@@#")
    print("#@@\033[92m2.*Press 'Zeroize' Button*\033[38;2;0;0;1m@@#")
    print("#@@\033[92m3.*Unmount SD & Switch OFF*\033[38;2;0;0;1m@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#")
    print("#@@@@@@@@@@@\033[0m" + microsd(SD) + "\033[38;2;0;0;1m@@@@@@@@@@@#")
    print("################################\033[38;2;0;0;1m")
    print("        " + comm() + "               " + comm() + " \n\n")


def microsd(action):
    if action == "NOinsert":
        return "\033[0m[======]\033[30m"
    if action == "insert":
        return "\033[0m[\033[40m      \033[m]\033[30m"


def firstMenu():
    import sys

    global SD
    global LIGHT
    toy()
    tarjeta = SDCard("Micro-SD", "8GB", "FAT32")
    while True:
        userchoice = input("\nPlease, enter a number: ")
        if userchoice == "1" or userchoice == "2" or userchoice == "3":
            break
        print("\n\033[91m Error.Invalid option \033[0m\n")
    if userchoice == "1":
        print("\n\033[93m  * You inserted the Micro-SD... *\033[0m\n")
        SD = "insert"
        readableCard = tarjeta.SDmount(RUTASD)
        if not readableCard:
            SD = "NOinsert"
            firstMenu()
            return False
        toy()
        readFU()
        tarjeta.SDumount(RUTASD)
    elif userchoice == "2":
        print("\033[93m \n* You zeroized the Toy Encryptor... *\033[0m\n")
        LIGHT = False
        readableCard = tarjeta.SDmount(RUTASD)
        if not readableCard:
            SD = "NOinsert"
            toy()
            return False
        SD = "insert"
        Zeroice()
        tarjeta.SDumount(RUTASD)
    else:
        turnOff(tarjeta)
        sys.exit()


def turnOff(tarjeta):
    global SD
    global LIGHT
    print("\n\033[93m* Switched OFF... No more BIP BIP BOOP *\n")
    LIGHT = False
    readable = tarjeta.SDmount(RUTASD)
    if not readable:
        print(
            "\n\033[93m*No Micro-SD card pending to retire after switching off...*\n\033[0m"
        )
        SD = "NOinsert"
    else:
        print(
            "\n\033[93m*Micro-SD Card pending to retire... Retire it from device*\n\033[0m"
        )
        SD = "insert"
    toy()


def deleteDB():
    import os, shlex

    try:
        retdir = os.getcwd()
        if os.getcwd() != DATABASE:
            os.chdir(DATABASE)
        code = os.system("sudo rm " + shlex.quote("users.json") + " > /dev/null 2>&1")
        if code != 0:
            print("\033[91mDatabase was mainly cleansed")
        os.chdir(retdir)

    except:
        print("\n\033[91mNo database to delete\033[0m\n")


def init():
    print("\n\033[93m Toy Encryptor turned ON...\n * Device sounds... BIP BIP BOOP *\n")
    print(
        " * LED Light turned on... Device ready to use... * \n * There's not Micro-SD inserted to read yet... *"
    )
    print("\nNow device is ready for user manipulation... What would you do? \n\033[0m")
    firstMenu()


def readFU():
    import os

    print("\n\033[93m *Reading for updates...*\n")
    checkForUpdates = True
    try:
        routeUpdatesList = os.listdir(ROUTEUPDATES)
        if len(routeUpdatesList) <= 0:
            print("\n\033[32mThere are no Firmware updates\033[0m\n")
            checkForUpdates = False

        if checkForUpdates:
            ui = 0
            for file in routeUpdatesList:
                if file.lower().__contains__(".sh"):
                    print(
                        "\n\033[94m ***---- PREPARING UPTADE " + str(ui) + "----***\n"
                    )
                    updatesExec(ROUTEUPDATES, file)
                    ui += 1
            print("\n\033[32mEnd of updates \033[0m\n")
        readMI()
    except FileNotFoundError:
        print("\n\033[91mNo file at reading updates \033[0m\n")
    except NotADirectoryError:
        print("\n\033[91mNo directory at reading updates \033[0m\n")


def updatesExec(path, file):
    import os
    import shlex

    ret_route = os.getcwd()
    if os.getcwd() != path:
        os.chdir(path)
    os.system("ls")
    os.system("sudo chmod +x " + shlex.quote(file))
    os.system("/bin/bash " + file)
    os.system("sudo rm " + file + " > /dev/null 2>&1")
    os.chdir(ret_route)


def readMI():
    import os

    global TRIESCOUNTER, LIGHT
    print("\n\033[93m Reading for Missions...\n\033[91m")
    try:
        keyLoadingList = os.listdir(ROUTEKEYLOADING)
        nfiles = len(keyLoadingList)

        if nfiles <= 0:
            print(
                "\n\033[32mThere are no keys to read. Unable to use device. \n\033[0m"
            )
            firstMenu()
            return False

        for file in keyLoadingList:
            nfiles -= 1
            verifyLogin = False
            if file.lower().__contains__(".json"):
                auxPath = ROUTEKEYLOADING + "/" + file
                verifyLogin = logIn(auxPath)

                if verifyLogin is True:
                    TRIESCOUNTER = 3
                    break

                if TRIESCOUNTER <= 0:
                    print(
                        "\033[91m\nERROR! ERROR! DETECTED INTRUDER. STARTING SECURITY PROCEDURE\n\033[0m"
                    )
                    erase = os.listdir(ROUTEKEYLOADING)
                    if len(erase) > 0:
                        for auxPath in erase:
                            eraseKeys = ROUTEKEYLOADING + "/" + auxPath
                            toast(eraseKeys)
                        break  # Intentional jump here
                    # Exploit : Never Ends execution afer toasting,
                    # access to comms without key. Just stops reading credentials after having deleted (BAD CODE).
                    # Now Key is none, comms are wit1hout encrypting

                if nfiles == 0 and TRIESCOUNTER > 0:
                    print(
                        "\n\033[91mCould not verify credentials credentials for Encryptor Usage\n\033[0m"
                    )
                    LIGHT = False
                    toy()
                    return False
        commsMenu()
    except FileNotFoundError:
        print("\n\033[91mUnexpected error reading keys or database\033[0m\n")


def commsMenu():
    global COMMWRITE, COMMSPEAK, NONCONCURRENTCOMS
    print("\n\033[38;5;129m Algorithm: -> " + ALGORITHM + " <-\033[0m")
    print("\033[38;5;129m With Key: -> " + ENCRYPTIONKEY + " <-\033[0m\n")
    print(
        "\n\033[93m* Communications are ready. Device waiting for user action... \033[0m*\n"
    )
    while True:
        userinput = input(
            "\033[92m\n1. * Turn on and attach the computer to write a message for the squad \n(Lights YELLOW left LED)*\n\n2. "
            + "* Turn on and attach the walkie-talkie to send voice message to the squad \n(Lights BLUE Right LED) *\n\n3. * Leave communications * \n"
        )
        if userinput == "1" or userinput == "2" or userinput == "3":
            break
        print("\033[91m \nInvalid action for comms system\033[0m\n")

    if userinput == "1":
        print(
            "\n\033[93m * Click! - Attached computer to encryptor. \nTurned on... * \n"
        )
        COMMWRITE = True
        toy()
        commsWrite()
    elif userinput == "2":
        print(
            "\n\033[93m * Click! - Attached walkie-talkie to encryptor. \nTurned on... * \n"
        )
        NONCONCURRENTCOMS = True
        COMMSPEAK = True
        toy()
        commsVoice()
    else:
        firstMenu()


def comm():
    global COMMSPEAK, COMMWRITE, NONCONCURRENTCOMS

    if NONCONCURRENTCOMS == True:
        NONCONCURRENTCOMS = False
        return "\033[30m0"

    if COMMSPEAK == True and COMMWRITE == False:
        COMMWRITE = False
        COMMWRITE = False
        return "\033[38;2;0;128;255m0\033[m"

    if COMMWRITE == True and COMMSPEAK == False:
        COMMWRITE = False
        COMMSPEAK = False
        return "\033[38;2;255;255;0m0\033[m"

    return "\033[38;2;0;0;1m0"


def communicate(inpt, mode):
    try:
        encriptador = Encryptor(ALGORITHM, ENCRYPTIONKEY)
        msg_sent = encriptador.EncrSelect(inpt)
        respuesta = encriptador.EncrSelect(encriptador.randomWarFrase()).__str__()
        # Write chat for communicate
        if mode.upper() == "CHAT":
            if len(inpt) > 0:
                print(
                    "\n\033[38;5;129mSquad Member - "
                    + COMBATIENT
                    + " >>> \033[38;5;208mS"
                    + msg_sent.__str__()
                    + "\033[0m\n"
                )
                ## Aqui se envia el mensaje a los otros cifradores, para este ejemplo no se implementa una comunicación real. Únicamente se muestra el mensaje enviado
                print(
                    "\033[38;5;129mSquad Member(s) >>>\033[38;5;208m "
                    + respuesta
                    + "\033[38;5;129m\n"
                )
        elif mode.upper() == "VOICE":
            # decode missing
            msg = encriptador.DecrSelect(respuesta)
            return msg
        else:
            raise Exception()
    except Exception:
        print("\n\033[91mError in comms mode\033[0m\n")
        return False


def commsWrite():
    global COMMWRITE
    while True:
        inpt = input(
            "\n\033[32mComputer ready. Write down your message, other encryptors belonging to the same squad will receive your message\033[0m\n\n"
        )
        communicate(inpt, "CHAT")
        while True:
            respuesta = input("Do you want to send other written message? (y/n): ")
            if respuesta.lower() == "n":
                COMMWRITE = False
                commsMenu()
            elif respuesta.lower() == "y":
                break
            else:
                print("\n\033[91mInvalid Option\033[0m\n")


def readAudio():
    import speech_recognition as sr
    from gtts import gTTS
    from audioClass import walkieTalkie
    import os
    import pulsectl

    sample_rate = 0
    channel = 0
    walkie = walkieTalkie("Walkie-Talkie", "2.4GHz", "16", "44100Hz")
    try:
        with pulsectl.Pulse("") as pulse:
            for source in pulse.source_list():
                if source.description.startswith("Monitor of USB"):
                    channel = int(source.channel_count)
                    sample_rate = source.configured_latency
                    break

        # print walkie info
        print(
            "\n\033[93m* Walkie-Talkie Info: \n"
            + walkie.__str__()
            + "\nReady for usage... Recording...\033[0m\n"
        )
        audio = walkie.record(channel)
        audio_data = sr.AudioData(audio, sample_rate, 2)
        lectorAudio = sr.Recognizer()
        texto = lectorAudio.recognize_google(audio_data, language="es-ES")
        respuesta = communicate(texto, "VOICE")
        tts = gTTS(respuesta, lang="es")
        tts.save("respuesta.mp3")
        os.system(f"mpg321 respuesta.mp3")
    except Exception as e:
        print(
            "\n\033[91mCould not read audio INPUT. Try again connections to plug-in the walkie."
            + " Additional info in : "
            + str(e)
            + "\033[0m\n"
        )
        return False


def commsVoice():
    global COMMSPEAK
    while True:
        canSendAudio = readAudio()
        while True:
            if canSendAudio == False:
                print(
                    "\n\033[91mPerhaps there are problems with the voice mode. Better not use this mode at the moment\033[0m\n"
                )
                COMMSPEAK = False
                commsMenu()
            respuesta = input("Do you want to send other voice message? (y/n): ")
            if respuesta.lower() == "n":
                COMMSPEAK = False
                commsMenu()
            elif respuesta.lower() == "y":
                break
            else:
                print("\n\033[91mInvalid Option\033[0m\n")


def Zeroice():
    import os
    import sys

    global SD
    try:
        keyLoadingList = os.listdir(ROUTEKEYLOADING)
        if len(keyLoadingList) > 0:
            for file in keyLoadingList:
                if file.lower().__contains__(".json"):
                    auxPath = ROUTEKEYLOADING + "/" + file
                    toast(auxPath)
            toy()
            deleteDB()
            print("\n\033[93m Zeroized device... Useless Toy Now.. Switching OFF!\n")
            print("\n* STOPPED BIP BIP BOOP . Retire Micro-SD* \033[0m\n")
            sys.exit()
        else:
            toy()
            deleteDB()
            print("\n\033[93m * Nothing happened *\033[0m\n")
    except FileNotFoundError:
        print("\n\033[91m Unexpected error zeroizing!! \033[0m\n")


def toast(path):
    import os

    global ALGORITHM
    ALGORITHM = ""

    os.remove(path)  # Limpiando json file to empty

    # Limpia datos de firmware updates si los hay
    aLimpiar = os.listdir(ROUTEUPDATES)
    if len(aLimpiar) > 0:
        for file in aLimpiar:
            auxPath = ROUTEUPDATES + "/" + file
            os.remove(auxPath)


def verifySquad(squad):
    number = squad.split("-")[1]

    if int(number) in range(11):
        return True

    return False


def readDB():
    import shlex
    import os
    import json, sys

    global LIGHT
    try:
        names = []
        retdir = os.getcwd()
        if os.getcwd() != DATABASE:
            os.chdir(DATABASE)
        os.system("sudo chmod +r " + shlex.quote("users.json") + " > /dev/null 2>&1")

        with open("users.json", "r") as file:
            usersDatabase = json.load(file)
            file.close()
            for auxuser in usersDatabase:
                names.append(auxuser["username"])
        os.chdir(retdir)
        return names
    except:
        print(
            "\n\033[91mCould not read database. Please remove SD and load it again database\033[0m\n"
        )
        LIGHT = False
        toy()
        sys.exit()


def logIn(auxPath):
    global TRIESCOUNTER
    global ATTEMPTS
    try:
        import json

        names = readDB()

        with open(auxPath, "r") as file:
            user = json.load(file)
            file.close()

            if (
                len(user["username"]) <= 0
                or len(user["role"]) <= 0
                or len(user["algorithm"]) <= 0
            ):
                raise Exception()

        if not user["username"] in names:
            print(
                "\n\033[91mUnexistent user the one loaded at Micro-SD credentials\033[0m\n"
            )
            raise Exception()

        if not user["role"].lower().__contains__("squad"):
            print(
                "\n\033[91mUser is not part of the Mission. Does not belong to any squad\033[0m\n"
            )
            raise Exception()
        elif not verifySquad(user["role"]):
            print("\n\033[91mUnexistent squad. Could not verify.\033[0m\n")
            raise Exception()

        return setEncryptorKey(user["algorithm"], user["key"], user["username"])
    except Exception:
        ATTEMPTS += 1
        TRIESCOUNTER -= 1
        print(
            "\n\033[91mThere was a problem reading credentials. Attempt -> "
            + str(ATTEMPTS)
            + "\033[0m\n"
        )


def setEncryptorKey(algorithm, key, combatient):
    global ALGORITHM, ENCRYPTIONKEY, COMBATIENT
    if len(algorithm) > 0 and len(combatient):
        COMBATIENT = combatient
        ALGORITHM = algorithm
        ENCRYPTIONKEY = key
        return True

    return False


init()
