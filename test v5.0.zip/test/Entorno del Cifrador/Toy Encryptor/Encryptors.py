from chepy import Chepy


class Encryptor:
    def __init__(self, alg, enck):
        self.alg = alg
        self.enck = enck

    def randomWarFrase(self):
        import random

        phrases = [
            "¡Menos mal que has escrito!, nos ganan en número. Necesitamos refuerzos.",
            "¡Estás bien! Te dábamos por muerto.",
            "Estamos heridos, al borde de la muerte",
            "Herida de bala... me queda poco tiempo... Ayuda...",
            "¡De camino!",
            "¡Sin munición!",
            "No puedo escribir ahora, la guerra está que arde.",
        ]
        return random.choice(phrases)

    def EncrSelect(self, input):
        import sys

        try:
            msg = input

            if self.alg.upper() == "XOR":
                msg = Chepy(input).xor(self.enck, enck_type="utf-8").to_hex()
            elif self.alg.upper() == "VINGERE":
                msg = Chepy(input).vigenere_encode(self.enck).o
            elif self.alg.upper() == "3DES":
                msg = Chepy(input).triple_des_encrypt(self.enck, mode="ECB").o
            elif self.alg.upper() == "ROT13":
                msg = Chepy(input).rot_13()
            elif self.alg.upper() == "ROT47":
                msg = Chepy(input).rot_47().out
            elif self.alg.upper() == "RC4":
                msg = Chepy(input).rc4_encrypt(self.enck).o
            elif self.alg.upper() == "AES-ECB":
                msg = Chepy(input).aes_encrypt(self.enck, mode="ECB").o

            return msg
        except Exception:
            print(
                "\n\033[91mLOADED FORBIDDEN KEY. STOPPING COMMS. LOAD VALID KEY.\033[0m"
            )
            sys.exit()

    def DecrSelect(self, input):
        import sys

        try:
            msg = input

            if self.alg.upper() == "XOR":
                msg = Chepy(input).xor(self.enck, enck_type="utf-8").to_hex()
            elif self.alg.upper() == "VINGERE":
                msg = Chepy(input).vigenere_decode(self.enck).o
            elif self.alg.upper() == "3DES":
                msg = Chepy(input).triple_des_decrypt(self.enck, mode="ECB").o
            elif self.alg.upper() == "ROT13":
                msg = Chepy(input).rot_13()
            elif self.alg.upper() == "ROT47":
                msg = Chepy(input).rot_47().out
            elif self.alg.upper() == "RC4":
                msg = Chepy(input).rc4_decrypt(self.enck).o
            elif self.alg.upper() == "AES-ECB":
                msg = Chepy(input).aes_decrypt(self.enck, mode="ECB").o

            return msg
        except Exception:
            print(
                "\n\033[91mLOADED FORBIDDEN KEY. STOPPING COMMS. LOAD VALID KEY.\033[0m"
            )
            sys.exit()
