#!/bin/bash

# Simulación de carga con una barra de ASCII

# Número de iteraciones
n=10

echo "Firmware loading..."

# Bucle de simulación de carga
for i in $(seq 1 $n)
do
  # Simulación de proceso
  sleep 1

  # Cálculo de progreso
  progress=$((i * 100 / n))

  # Impresión de barra de ASCII
  echo -ne "Progress: [$((i * 10))%] ["
  for ((j=0; j<$i; j++))
  do
    echo -ne "#"
  done
  for ((j=$i; j<$n; j++))
  do
    echo -ne "-"
  done
  echo -ne "]"
  echo -ne " ($progress%)"
done

echo -e "
 Firmware loading completed."
