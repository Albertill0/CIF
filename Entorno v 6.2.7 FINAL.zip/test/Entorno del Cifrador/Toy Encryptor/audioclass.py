'''Módulo para generar el walkieTalkie de comms por voz'''
import pvrecorder
import io
import wave
import speech_recognition as sr
class WalkieTalkie():

    '''Clase para crear instancias de walkie'''

    def __init__(self, tipo, band, channel, frequency):
        '''Constructor de la clase'''
        self.tipo = tipo
        self.band = band
        self.channel = channel
        self.frequency = frequency

    def to_string(self):

        '''Método toString de la clase'''

        return (
            "Type: "
            + self.tipo
            + "\nBand: "
            + self.band
            + "\nChannel: "
            + self.channel
            + "\nFrequency: "
            + self.frequency
        )

    def record(self):
        '''Método para convertir audio a texto'''
        recorder = pvrecorder.PvRecorder(1, 512)
        contador = 100
        text = ""
        audio_bytes = []
        try:
            while True:
                if contador == 0:
                    break
                recorder.start()
                if contador % 10 == 0:
                    print(str(contador) + " seconds Left to talk...")
                contador -= 5
                frame = recorder.read()
                if contador == 0:
                    recorder.stop()

                    for num in frame:
                        if type(num) != "NoneType":
                            if num <= 0:
                                audio_bytes.append(str(abs(num)).encode('utf-8'))
                                continue
                            audio_bytes.append(str(num).encode('utf-8'))
                    # Convert audio_data to WAV format
                    with io.BytesIO() as wav_file:
                        wav_writer = wave.open(wav_file, 'wb')
                        wav_writer.setnchannels(1)
                        wav_writer.setsampwidth(2)
                        wav_writer.setframerate(512)
                        for b in audio_bytes:
                            wav_writer.writeframes(b)
                        wav_writer.close()
                        wav_file.seek(0)

                        recognizer = sr.Recognizer()
                        with sr.AudioFile(wav_file) as source:
                            audio = recognizer.record(source)  # Load the audio file
                    text = str(audio.frame_data)
                    #text += recognizer.recognize_sphinx(audio)
                recorder.stop()
            return text
        finally:
            recorder.delete()

