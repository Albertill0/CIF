'''Módulo observador que actua de auditor'''
import sys
from datetime import datetime

class Auditor():

    '''Clase para crear instancias de auditor que apunten'''

    def __init__(self, nombre, target,cwd):
        '''Constructor de la clase'''
        self.nombre = nombre
        self.target = target
        self.cwd = cwd + '/archivo_auditoria.txt'

    def start_audit(self,user,msg,name_function):
        '''Método que usa el auditor para apuntar la auditoría'''

        try:
            marcatiempos = datetime.now()
            with open(self.cwd,'a+') as auditing:

                auditing.write("|---------------------Auditory automatically provided by"
                +"-----------------"+self.to_string()+"---------------------------|\n\n")

                auditing.write("//  ("
                            + marcatiempos.ctime()
                            + ")  >>>>>> [" + msg + "] at function ["
                            + name_function +"]"+ " >>>>>> Individual : " + user + "  //\n\n")
                auditing.close()
        except FileNotFoundError:
            print("\033[91mInstall a Micro-SD card for functioning, please\033[0m")
            sys.exit(-1)


    def to_string(self):

        '''Método to string de la clase'''

        return "Nombre: " + self.nombre + ", Target: " + self.target




