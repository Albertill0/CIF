'''Módulo para la manipulación de Micro-SD'''
import os
import time

class SdCard():

    '''Clase para crear instancias de SD'''

    def __init__(self, name, size, tipo):
        '''Constructor'''
        self.name = name
        self.size = size
        self.tipo = tipo

    def sd_mount(self, route):

        '''Método que monta la SD'''

        try:
            if os.path.ismount(route):
                print("\033[93mSD card already mounted.\033[0m")
                return True

            print("\033[93mMounting SD card...")
            code = os.system("sudo mount -o rwx /dev/mmcblk0p2 " + route)

            if code != 0:
                print("\033[91mSD card impossible to be mounted\033[0m")
                return False

            print("Inserted SD FAT32 Card of tipo: -> " + self.to_string())
            print("SD card mounted successfully\033[0m")
            return True
        except IOError:
            print("\033[91mUnexpected exception\033[0m")
            return False

    def sd_umount(self, route):

        '''Método que desmonta la SD'''

        print("\033[93mWaiting 4 seconds to complete card reading...\033[0m")
        time.sleep(4)
        try:
            if not os.path.ismount(route):
                print(
                    "\033[93mSD card impossible to be "
                    +"umounted. Already unmounted\033[0m"
                )
                return True

            print("\033[93mUnmounting SD card...")
            code = os.system("sudo umount -l " + route)

            if code != 0:
                print("\033[91mSD card impossible to be unmounted\033[0m")
                return False

            print("SD card unmounted successfully\033[0m")
            return True
        except IOError:
            print("\033[91mUnexpected exception\033[0m")
            return False

    def to_string(self):
        '''Método to String de la clase'''
        return "Name: " + self.name + "\nSize: " + self.size + "\ntipo: " + self.tipo
