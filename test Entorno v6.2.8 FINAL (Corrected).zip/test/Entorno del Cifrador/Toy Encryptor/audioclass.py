'''Módulo para generar el walkieTalkie de comms por voz'''
import pvrecorder
import io
import wave
import speech_recognition as sr
class WalkieTalkie():

    '''Clase para crear instancias de walkie'''

    def __init__(self, tipo, band, channel, frequency):
        '''Constructor de la clase'''
        self.tipo = tipo
        self.band = band
        self.channel = channel
        self.frequency = frequency

    def to_string(self):

        '''Método toString de la clase'''

        return (
            "Type: "
            + self.tipo
            + "\nBand: "
            + self.band
            + "\nChannel: "
            + self.channel
            + "\nFrequency: "
            + self.frequency
        )

    def record(self): 
        '''Método para convertir audio a texto''' 
        #Inicializamos el objeto de captura de audio con puerto 1 
        recorder = pvrecorder.PvRecorder(1, 512) 
        #Inicializamos un contador de 100 segundos para limitar la lectura 
        contador = 100 
        #Inicializamos una array para contener los bytes del audio que capturamos 
        audio_bytes = [] 
        try: 
            while True: 
                #Iniciamos la lectura del objeto 
                recorder.start() 
                frame = recorder.read()
                recorder.stop() 

                #Cada 10 segundos mostramos el tiempo restante 
                if contador % 10 == 0: 
                    print(str(contador) + " seconds Left to talk...") 
                contador -= 5 
                #Leemos un frame del audio que entra 

                #Hacemos lectura de los byte para añadirlos a la array siempre 
                #y cuando no sea un byte Null
                for num in frame: 
                    if type(num) == "NoneType": 
                        continue
                    #Los bytes menores a 0 no los interpreta la librería de audio 
                    # #Por lo que se coge su valor absoluto 
                    if num <= 0: 
                        audio_bytes.append(str(abs(num)).encode('utf-8')) 
                        continue 
                    audio_bytes.append(str(num).encode('utf-8')) 

                #Leemos hasta que el contador termine 
                if contador != 0: 
                #De no terminar el contador sigue leyendo
                    continue 

                fileName = 'audio.wav'
                waver = wave.Wave_write(fileName)
                # Convierte audio_data a WAV format 
                with waver as wav_file: 
                    wav_file.setnchannels(1) 
                    wav_file.setsampwidth(2)
                    wav_file.setframerate(512) 
                    for b in audio_bytes:
                        wav_file.writeframes(b) 
                    wav_file.close() 
                    #Interpreta el archivo de audio y convierte a texto 
                recognizer = sr.Recognizer() 
                with sr.AudioFile(fileName) as source: 
                    audio = recognizer.record(source)
                
                text = "Ejemplo de remplazo por el comentario de sphinx"
                #text = recognizer.recognize_sphinx(audio) 
                return text 
        finally:
            recorder.delete()